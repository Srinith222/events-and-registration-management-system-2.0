import type { ReactNode } from "react";
import { motion } from "framer-motion";
import { AlertCircle, CalendarPlus, LoaderCircle, Sparkles } from "lucide-react";

export const pageMotion = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -8 },
  transition: { duration: 0.34, ease: [0.2, 0.65, 0.3, 1] as const },
};

export function PageMotion({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <motion.div {...pageMotion} className={className}>{children}</motion.div>;
}

export function StatusBadge({ status }: { status: "draft" | "published" | "archived" | "confirmed" | "pending" | "cancelled" | "paid" | "unpaid" | "refunded" | "waived" }) {
  const label = status.charAt(0).toUpperCase() + status.slice(1);
  return <span className={`status-badge status-${status}`}><span className="status-dot" />{label}</span>;
}

export function LoadingState({ label = "Loading your workspace…" }: { label?: string }) {
  return <div className="loading-state"><LoaderCircle size={20} className="spin" aria-hidden="true" /><span>{label}</span></div>;
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return <div className="error-state"><AlertCircle size={19} /><div><strong>We couldn't load this view</strong><p>{message}</p>{onRetry && <button className="text-button" onClick={onRetry}>Try again</button>}</div></div>;
}

export function EmptyState({
  icon,
  title,
  description,
  action,
  actionLabel,
}: {
  icon?: ReactNode;
  title: string;
  description: string;
  action?: () => void;
  actionLabel?: string;
}) {
  return <motion.div className="empty-state" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
    <div className="empty-icon">{icon ?? <Sparkles size={23} />}</div>
    <h3>{title}</h3>
    <p>{description}</p>
    {action && actionLabel && <button className="button button-primary" onClick={action}><CalendarPlus size={16} />{actionLabel}</button>}
  </motion.div>;
}

export function SectionHeading({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return <div className="section-heading"><div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div>{action}</div>;
}

export function Skeleton({ className = "" }: { className?: string }) {
  return <div className={`skeleton ${className}`} aria-hidden="true" />;
}
