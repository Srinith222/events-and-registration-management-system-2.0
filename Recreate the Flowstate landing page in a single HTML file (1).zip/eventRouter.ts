import { and, asc, count, desc, eq, gte, inArray, isNotNull, ne } from "drizzle-orm";
import { EVENT_OWNER_EMAIL } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { nanoid } from "nanoid";
import { z } from "zod";
import {
  attendees,
  events,
  registrations,
  users,
  workshopParticipants,
  workshops,
} from "../drizzle/schema";
import { getDb } from "./db";
import { isGmailConfigured, sendRegistrationConfirmation } from "./_core/registrationMail";
import { ownerProcedure as protectedProcedure, publicProcedure, router } from "./_core/trpc";

const eventForm = z.object({
  title: z.string().trim().min(3).max(180),
  description: z.string().max(8000).default(""),
  type: z.enum(["event", "workshop"]),
  category: z.string().trim().min(1).max(80).default("Community"),
  startsAt: z.string().min(1),
  endsAt: z.string().min(1),
  venue: z.string().max(240).default(""),
  format: z.enum(["in_person", "online", "hybrid"]).default("in_person"),
  capacity: z.number().int().min(1).max(50000),
  coverUrl: z.union([z.string().url().max(1000), z.literal("")]).optional(),
  registrationOpensAt: z.string().optional(),
  registrationClosesAt: z.string().optional(),
  registrationFields: z.array(z.string().trim().min(1).max(100)).max(8).default([]),
  instructor: z.string().max(160).default(""),
  durationHours: z.number().min(0.25).max(500).default(1),
  materialCost: z.number().min(0).max(1000000).default(0),
  currency: z.string().length(3).default("USD"),
}).superRefine((input, context) => {
  for (const key of ["registrationOpensAt", "registrationClosesAt"] as const) {
    const value = input[key];
    if (value && Number.isNaN(Date.parse(value))) context.addIssue({ code: "custom", path: [key], message: "Choose a valid registration date and time." });
  }
  if (input.registrationOpensAt && input.registrationClosesAt) {
    const opensAt = Date.parse(input.registrationOpensAt);
    const closesAt = Date.parse(input.registrationClosesAt);
    if (!Number.isNaN(opensAt) && !Number.isNaN(closesAt) && opensAt > closesAt) {
      context.addIssue({ code: "custom", path: ["registrationClosesAt"], message: "The registration close time must be after the opening time." });
    }
  }
});

const normalizeEmail = (email: string) => email.trim().toLowerCase();
const slugBase = (title: string) =>
  title.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 130) || "event";
const makeTicketCode = () => nanoid(10).toUpperCase();
const asDate = (value?: string) => value ? new Date(value) : null;

function parseRegistrationFields(value: string | null): string[] {
  if (!value) return [];
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string").slice(0, 8) : [];
  } catch {
    return [];
  }
}

async function requireDb() {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "The MySQL database is not available right now." });
  return db;
}

async function getPrimaryOwnerId() {
  const db = await requireDb();
  const rows = await db.select({ id: users.id }).from(users).where(eq(users.email, EVENT_OWNER_EMAIL)).limit(1);
  return rows[0]?.id ?? null;
}

async function listWorkspace(ownerId: number) {
  const db = await requireDb();
  const items = await db.select().from(events).where(eq(events.ownerId, ownerId)).orderBy(desc(events.startsAt));
  if (!items.length) return [];
  const eventIds = items.map((event) => event.id);
  const [workshopRows, eventCounts, eventCheckins] = await Promise.all([
    db.select().from(workshops).where(inArray(workshops.eventId, eventIds)),
    db.select({ eventId: registrations.eventId, total: count() })
      .from(registrations).where(and(inArray(registrations.eventId, eventIds), ne(registrations.status, "cancelled")))
      .groupBy(registrations.eventId),
    db.select({ eventId: registrations.eventId, total: count() })
      .from(registrations).where(and(inArray(registrations.eventId, eventIds), ne(registrations.status, "cancelled"), isNotNull(registrations.checkedInAt)))
      .groupBy(registrations.eventId),
  ]);
  const workshopIds = workshopRows.map((workshop) => workshop.id);
  const [participantCounts, participantCheckins] = workshopIds.length ? await Promise.all([
    db.select({ workshopId: workshopParticipants.workshopId, total: count() })
      .from(workshopParticipants).where(and(inArray(workshopParticipants.workshopId, workshopIds), ne(workshopParticipants.status, "cancelled")))
      .groupBy(workshopParticipants.workshopId),
    db.select({ workshopId: workshopParticipants.workshopId, total: count() })
      .from(workshopParticipants).where(and(inArray(workshopParticipants.workshopId, workshopIds), ne(workshopParticipants.status, "cancelled"), isNotNull(workshopParticipants.checkedInAt)))
      .groupBy(workshopParticipants.workshopId),
  ]) : [[], []];
  const workshopByEvent = new Map(workshopRows.map((row) => [row.eventId, row]));
  const eventCountById = new Map(eventCounts.map((row) => [row.eventId, row.total]));
  const eventCheckinById = new Map(eventCheckins.map((row) => [row.eventId, row.total]));
  const participantCountById = new Map(participantCounts.map((row) => [row.workshopId, row.total]));
  const participantCheckinById = new Map(participantCheckins.map((row) => [row.workshopId, row.total]));
  return items.map((event) => {
    const workshop = workshopByEvent.get(event.id) ?? null;
    const participantCount = workshop ? participantCountById.get(workshop.id) ?? 0 : 0;
    const participantCheckin = workshop ? participantCheckinById.get(workshop.id) ?? 0 : 0;
    return {
      ...event,
      registrationCount: eventCountById.get(event.id) ?? participantCount,
      checkInCount: eventCheckinById.get(event.id) ?? participantCheckin,
      workshopDetails: workshop ? {
        id: workshop.id,
        instructor: workshop.instructor,
        durationHours: Number(workshop.durationHours),
        materialCost: Number(workshop.materialCost),
        currency: workshop.currency,
        maxParticipants: workshop.maxParticipants,
      } : null,
    };
  });
}

async function listRegistrations(ownerId: number) {
  const db = await requireDb();
  const eventRows = await db.select({
    id: registrations.id,
    eventId: events.id,
    eventTitle: events.title,
    eventSlug: events.slug,
    type: events.type,
    attendeeId: attendees.id,
    fullName: attendees.fullName,
    email: attendees.email,
    phone: attendees.phone,
    status: registrations.status,
    paymentStatus: registrations.paymentStatus,
    ticketCode: registrations.ticketCode,
    registeredAt: registrations.registeredAt,
    checkedInAt: registrations.checkedInAt,
    comments: registrations.comments,
    notes: registrations.notes,
    customAnswers: registrations.customAnswers,
    registrationFields: events.registrationFields,
  }).from(registrations)
    .innerJoin(events, eq(registrations.eventId, events.id))
    .innerJoin(attendees, eq(registrations.attendeeId, attendees.id))
    .where(eq(events.ownerId, ownerId));
  const workshopRows = await db.select({
    id: workshopParticipants.id,
    eventId: events.id,
    eventTitle: events.title,
    eventSlug: events.slug,
    type: events.type,
    attendeeId: attendees.id,
    fullName: attendees.fullName,
    email: attendees.email,
    phone: attendees.phone,
    status: workshopParticipants.status,
    paymentStatus: workshopParticipants.paymentStatus,
    ticketCode: workshopParticipants.ticketCode,
    registeredAt: workshopParticipants.registeredAt,
    checkedInAt: workshopParticipants.checkedInAt,
    comments: workshopParticipants.comments,
    notes: workshopParticipants.notes,
    customAnswers: workshopParticipants.customAnswers,
    registrationFields: events.registrationFields,
  }).from(workshopParticipants)
    .innerJoin(workshops, eq(workshopParticipants.workshopId, workshops.id))
    .innerJoin(events, eq(workshops.eventId, events.id))
    .innerJoin(attendees, eq(workshopParticipants.attendeeId, attendees.id))
    .where(eq(events.ownerId, ownerId));
  return [
    ...eventRows.map((row) => ({ ...row, itemType: "event" as const })),
    ...workshopRows.map((row) => ({ ...row, itemType: "workshop" as const })),
  ].sort((a, b) => b.registeredAt.getTime() - a.registeredAt.getTime());
}

async function getOwnedRegistration(ownerId: number, itemType: "event" | "workshop", id: number) {
  const db = await requireDb();
  if (itemType === "event") {
    const rows = await db.select({ id: registrations.id, status: registrations.status, eventId: events.id, capacity: events.capacity }).from(registrations)
      .innerJoin(events, eq(registrations.eventId, events.id))
      .where(and(eq(registrations.id, id), eq(events.ownerId, ownerId))).limit(1);
    return rows[0];
  }
  const rows = await db.select({ id: workshopParticipants.id, status: workshopParticipants.status, eventId: events.id, capacity: workshops.maxParticipants }).from(workshopParticipants)
    .innerJoin(workshops, eq(workshopParticipants.workshopId, workshops.id))
    .innerJoin(events, eq(workshops.eventId, events.id))
    .where(and(eq(workshopParticipants.id, id), eq(events.ownerId, ownerId))).limit(1);
  return rows[0];
}

export const eventRouter = router({
  mailStatus: protectedProcedure.query(() => ({
    sender: EVENT_OWNER_EMAIL,
    configured: isGmailConfigured(),
    aiGreeting: true,
    model: "gpt-5-nano",
  })),

  overview: protectedProcedure.query(async ({ ctx }) => {
    const [workspace, rows] = await Promise.all([listWorkspace(ctx.user.id), listRegistrations(ctx.user.id)]);
    const now = new Date();
    const active = rows.filter((row) => row.status !== "cancelled");
    const confirmed = active.filter((row) => row.status === "confirmed");
    const pending = active.filter((row) => row.status === "pending");
    const upcoming = workspace.filter((event) => event.status === "published" && event.startsAt >= now)
      .sort((a, b) => a.startsAt.getTime() - b.startsAt.getTime()).slice(0, 4);
    const trend = Array.from({ length: 6 }, (_, index) => {
      const month = new Date(now.getFullYear(), now.getMonth() - (5 - index), 1);
      const key = `${month.getFullYear()}-${String(month.getMonth() + 1).padStart(2, "0")}`;
      return {
        key,
        label: month.toLocaleDateString("en-US", { month: "short" }),
        registrations: active.filter((row) => `${row.registeredAt.getFullYear()}-${String(row.registeredAt.getMonth() + 1).padStart(2, "0")}` === key).length,
        checkIns: active.filter((row) => row.checkedInAt && `${row.checkedInAt.getFullYear()}-${String(row.checkedInAt.getMonth() + 1).padStart(2, "0")}` === key).length,
      };
    });
    const capacity = workspace.filter((event) => event.status === "published").reduce((sum, event) => sum + event.capacity, 0);
    return {
      totals: {
        events: workspace.length,
        published: workspace.filter((event) => event.status === "published").length,
        registrations: active.length,
        pendingRegistrations: pending.length,
        confirmedRegistrations: confirmed.length,
        checkIns: active.filter((row) => row.checkedInAt).length,
        attendanceRate: confirmed.length ? Math.round(active.filter((row) => row.status === "confirmed" && row.checkedInAt).length / confirmed.length * 100) : 0,
        capacity,
        utilization: capacity ? Math.round(active.length / capacity * 100) : 0,
      },
      upcoming,
      trend,
      recentRegistrations: rows.slice(0, 6),
      popularEvents: [...workspace].sort((a, b) => b.registrationCount - a.registrationCount).slice(0, 4),
    };
  }),

  workspaceList: protectedProcedure.query(({ ctx }) => listWorkspace(ctx.user.id)),

  byId: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ ctx, input }) => {
    const db = await requireDb();
    const rows = await db.select().from(events).where(and(eq(events.id, input.id), eq(events.ownerId, ctx.user.id))).limit(1);
    const event = rows[0];
    if (!event) throw new TRPCError({ code: "NOT_FOUND", message: "Event not found." });
    const workspace = await listWorkspace(ctx.user.id);
    return workspace.find((item) => item.id === event.id)!;
  }),

  create: protectedProcedure.input(eventForm).mutation(async ({ ctx, input }) => {
    const db = await requireDb();
    const startsAt = new Date(input.startsAt);
    const endsAt = new Date(input.endsAt);
    if (!Number.isFinite(startsAt.getTime()) || !Number.isFinite(endsAt.getTime()) || endsAt <= startsAt) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "Choose a valid end time after the start time." });
    }
    const slug = `${slugBase(input.title)}-${nanoid(6).toLowerCase()}`;
    const id = await db.transaction(async (tx) => {
      const [created] = await tx.insert(events).values({
        ownerId: ctx.user.id,
        slug,
        title: input.title,
        description: input.description,
        type: input.type,
        category: input.category,
        startsAt,
        endsAt,
        venue: input.venue,
        format: input.format,
        capacity: input.capacity,
        status: "draft",
        coverUrl: input.coverUrl || null,
        registrationOpensAt: asDate(input.registrationOpensAt),
        registrationClosesAt: asDate(input.registrationClosesAt),
        registrationFields: JSON.stringify(input.registrationFields),
      }).$returningId();
      if (input.type === "workshop") {
        await tx.insert(workshops).values({
          eventId: created.id,
          instructor: input.instructor,
          durationHours: input.durationHours.toFixed(2),
          materialCost: input.materialCost.toFixed(2),
          currency: input.currency.toUpperCase(),
          maxParticipants: input.capacity,
        });
      }
      return created.id;
    });
    return { id, slug };
  }),

  update: protectedProcedure.input(eventForm.safeExtend({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
    const db = await requireDb();
    const existingRows = await db.select().from(events).where(and(eq(events.id, input.id), eq(events.ownerId, ctx.user.id))).limit(1);
    const existing = existingRows[0];
    if (!existing) throw new TRPCError({ code: "NOT_FOUND", message: "Event not found." });
    if (existing.type !== input.type) throw new TRPCError({ code: "BAD_REQUEST", message: "The event type cannot be changed after creation." });
    const startsAt = new Date(input.startsAt);
    const endsAt = new Date(input.endsAt);
    if (!Number.isFinite(startsAt.getTime()) || !Number.isFinite(endsAt.getTime()) || endsAt <= startsAt) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "Choose a valid end time after the start time." });
    }
    await db.transaction(async (tx) => {
      const locked = await tx.select({ id: events.id }).from(events)
        .where(and(eq(events.id, input.id), eq(events.ownerId, ctx.user.id))).limit(1).for("update");
      if (!locked[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Event not found." });
      const [currentCount] = existing.type === "workshop"
        ? await tx.select({ total: count() }).from(workshopParticipants)
          .innerJoin(workshops, eq(workshopParticipants.workshopId, workshops.id))
          .where(and(eq(workshops.eventId, existing.id), ne(workshopParticipants.status, "cancelled")))
        : await tx.select({ total: count() }).from(registrations)
          .where(and(eq(registrations.eventId, existing.id), ne(registrations.status, "cancelled")));
      if (input.capacity < (currentCount?.total ?? 0)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Capacity cannot be lower than the number of active registrations." });
      }
      await tx.update(events).set({
        title: input.title,
        description: input.description,
        category: input.category,
        startsAt,
        endsAt,
        venue: input.venue,
        format: input.format,
        capacity: input.capacity,
        coverUrl: input.coverUrl || null,
        registrationOpensAt: asDate(input.registrationOpensAt),
        registrationClosesAt: asDate(input.registrationClosesAt),
        registrationFields: JSON.stringify(input.registrationFields),
      }).where(and(eq(events.id, input.id), eq(events.ownerId, ctx.user.id)));
      if (existing.type === "workshop") {
        await tx.update(workshops).set({
          instructor: input.instructor,
          durationHours: input.durationHours.toFixed(2),
          materialCost: input.materialCost.toFixed(2),
          currency: input.currency.toUpperCase(),
          maxParticipants: input.capacity,
        }).where(eq(workshops.eventId, input.id));
      }
    });
    return { success: true };
  }),

  setStatus: protectedProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["draft", "published", "archived"]) })).mutation(async ({ ctx, input }) => {
    const db = await requireDb();
    const rows = await db.update(events).set({ status: input.status })
      .where(and(eq(events.id, input.id), eq(events.ownerId, ctx.user.id)));
    if (rows[0].affectedRows === 0) throw new TRPCError({ code: "NOT_FOUND", message: "Event not found." });
    return { success: true };
  }),

  duplicate: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
    const db = await requireDb();
    const rows = await db.select().from(events).where(and(eq(events.id, input.id), eq(events.ownerId, ctx.user.id))).limit(1);
    const source = rows[0];
    if (!source) throw new TRPCError({ code: "NOT_FOUND", message: "Event not found." });
    const sourceWorkshop = source.type === "workshop"
      ? (await db.select().from(workshops).where(eq(workshops.eventId, source.id)).limit(1))[0]
      : null;
    const [created] = await db.insert(events).values({
      ownerId: ctx.user.id,
      slug: `${slugBase(`copy-${source.title}`)}-${nanoid(6).toLowerCase()}`,
      title: `Copy of ${source.title}`.slice(0, 180),
      description: source.description,
      type: source.type,
      category: source.category,
      startsAt: source.startsAt,
      endsAt: source.endsAt,
      venue: source.venue,
      format: source.format,
      capacity: source.capacity,
      status: "draft",
      coverUrl: source.coverUrl,
      registrationOpensAt: source.registrationOpensAt,
      registrationClosesAt: source.registrationClosesAt,
      registrationFields: source.registrationFields,
    }).$returningId();
    if (sourceWorkshop) {
      await db.insert(workshops).values({
        eventId: created.id,
        instructor: sourceWorkshop.instructor,
        durationHours: sourceWorkshop.durationHours,
        materialCost: sourceWorkshop.materialCost,
        currency: sourceWorkshop.currency,
        maxParticipants: sourceWorkshop.maxParticipants,
      });
    }
    return { id: created.id };
  }),

  listPublished: publicProcedure.query(async () => {
    const db = await requireDb();
    const ownerId = await getPrimaryOwnerId();
    if (!ownerId) return [];
    const now = new Date();
    const offerings = await db.select({
      id: events.id,
      slug: events.slug,
      title: events.title,
      description: events.description,
      type: events.type,
      category: events.category,
      startsAt: events.startsAt,
      endsAt: events.endsAt,
      venue: events.venue,
      format: events.format,
      capacity: events.capacity,
      coverUrl: events.coverUrl,
      registrationOpensAt: events.registrationOpensAt,
      registrationClosesAt: events.registrationClosesAt,
    }).from(events)
      .where(and(eq(events.ownerId, ownerId), eq(events.status, "published"), gte(events.startsAt, now)))
      .orderBy(asc(events.startsAt));
    if (!offerings.length) return [];
    const eventIds = offerings.map((event) => event.id);
    const [workshopRows, eventCounts] = await Promise.all([
      db.select().from(workshops).where(inArray(workshops.eventId, eventIds)),
      db.select({ eventId: registrations.eventId, total: count() }).from(registrations)
        .where(and(inArray(registrations.eventId, eventIds), ne(registrations.status, "cancelled")))
        .groupBy(registrations.eventId),
    ]);
    const workshopIds = workshopRows.map((workshop) => workshop.id);
    const participantCounts = workshopIds.length
      ? await db.select({ workshopId: workshopParticipants.workshopId, total: count() }).from(workshopParticipants)
        .where(and(inArray(workshopParticipants.workshopId, workshopIds), ne(workshopParticipants.status, "cancelled")))
        .groupBy(workshopParticipants.workshopId)
      : [];
    const workshopsByEvent = new Map(workshopRows.map((workshop) => [workshop.eventId, workshop]));
    const eventCountsById = new Map(eventCounts.map((row) => [row.eventId, row.total]));
    const participantCountsById = new Map(participantCounts.map((row) => [row.workshopId, row.total]));
    return offerings.map((event) => {
      const workshop = workshopsByEvent.get(event.id);
      const capacity = workshop?.maxParticipants ?? event.capacity;
      const registrationCount = workshop
        ? participantCountsById.get(workshop.id) ?? 0
        : eventCountsById.get(event.id) ?? 0;
      const registrationOpen = (!event.registrationOpensAt || event.registrationOpensAt <= now)
        && (!event.registrationClosesAt || event.registrationClosesAt >= now)
        && registrationCount < capacity;
      return {
        ...event,
        capacity,
        registrationCount,
        remainingSeats: Math.max(0, capacity - registrationCount),
        registrationOpen,
      };
    });
  }),

  getPublicBySlug: publicProcedure.input(z.object({ slug: z.string().min(1).max(180) })).query(async ({ input }) => {
    const db = await requireDb();
    const ownerId = await getPrimaryOwnerId();
    if (!ownerId) throw new TRPCError({ code: "NOT_FOUND", message: "This event is not available." });
    const rows = await db.select({
      id: events.id,
      slug: events.slug,
      title: events.title,
      description: events.description,
      type: events.type,
      category: events.category,
      startsAt: events.startsAt,
      endsAt: events.endsAt,
      venue: events.venue,
      format: events.format,
      capacity: events.capacity,
      coverUrl: events.coverUrl,
      registrationOpensAt: events.registrationOpensAt,
      registrationClosesAt: events.registrationClosesAt,
      registrationFields: events.registrationFields,
    }).from(events).where(and(eq(events.slug, input.slug), eq(events.status, "published"), eq(events.ownerId, ownerId))).limit(1);
    const event = rows[0];
    if (!event) throw new TRPCError({ code: "NOT_FOUND", message: "This event is not available." });
    let registrationCount = 0;
    let workshopDetails: { instructor: string; durationHours: number; materialCost: number; currency: string; maxParticipants: number } | null = null;
    if (event.type === "workshop") {
      const workshopRows = await db.select().from(workshops).where(eq(workshops.eventId, event.id)).limit(1);
      const workshop = workshopRows[0];
      if (workshop) {
        workshopDetails = {
          instructor: workshop.instructor,
          durationHours: Number(workshop.durationHours),
          materialCost: Number(workshop.materialCost),
          currency: workshop.currency,
          maxParticipants: workshop.maxParticipants,
        };
        const [total] = await db.select({ total: count() }).from(workshopParticipants)
          .where(and(eq(workshopParticipants.workshopId, workshop.id), ne(workshopParticipants.status, "cancelled")));
        registrationCount = total?.total ?? 0;
      }
    } else {
      const [total] = await db.select({ total: count() }).from(registrations)
        .where(and(eq(registrations.eventId, event.id), ne(registrations.status, "cancelled")));
      registrationCount = total?.total ?? 0;
    }
    const opens = event.registrationOpensAt ? event.registrationOpensAt <= new Date() : true;
    const notClosed = event.registrationClosesAt ? event.registrationClosesAt >= new Date() : true;
    const limit = workshopDetails?.maxParticipants ?? event.capacity;
    const publicEvent = {
      id: event.id,
      slug: event.slug,
      title: event.title,
      description: event.description,
      type: event.type,
      category: event.category,
      startsAt: event.startsAt,
      endsAt: event.endsAt,
      venue: event.venue,
      format: event.format,
      capacity: event.capacity,
      coverUrl: event.coverUrl,
      registrationOpensAt: event.registrationOpensAt,
      registrationClosesAt: event.registrationClosesAt,
      registrationFields: parseRegistrationFields(event.registrationFields),
    };
    return {
      event: publicEvent,
      workshopDetails,
      registrationCount,
      remainingSeats: Math.max(0, limit - registrationCount),
      registrationOpen: opens && notClosed && registrationCount < limit,
    };
  }),

  registerPublic: publicProcedure.input(z.object({
    slug: z.string().min(1).max(180),
    fullName: z.string().trim().min(2).max(160),
    email: z.string().trim().email().max(320),
    phone: z.string().trim().max(40).optional().default(""),
    comments: z.string().max(2500).optional().default(""),
    customAnswers: z.record(z.string(), z.string().max(500)).optional().default({}).refine((answers) => Object.keys(answers).length <= 8, "At most 8 registration answers are allowed."),
  })).mutation(async ({ input }) => {
    const db = await requireDb();
    const ownerId = await getPrimaryOwnerId();
    if (!ownerId) throw new TRPCError({ code: "NOT_FOUND", message: "This event is not available." });
    const email = normalizeEmail(input.email);
    const confirmation = await db.transaction(async (tx) => {
      const matching = await tx.select().from(events).where(and(eq(events.slug, input.slug), eq(events.status, "published"), eq(events.ownerId, ownerId))).limit(1).for("update");
      const event = matching[0];
      if (!event) throw new TRPCError({ code: "NOT_FOUND", message: "This event is not available." });
      const allowedQuestions = parseRegistrationFields(event.registrationFields);
      if (Object.keys(input.customAnswers).some((question) => !allowedQuestions.includes(question))) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "One or more registration answers do not match this event's questions." });
      }
      const now = new Date();
      if (event.registrationOpensAt && event.registrationOpensAt > now) throw new TRPCError({ code: "BAD_REQUEST", message: "Registration has not opened yet." });
      if (event.registrationClosesAt && event.registrationClosesAt < now) throw new TRPCError({ code: "BAD_REQUEST", message: "Registration has closed." });
      const attendeeRows = await tx.select({ id: attendees.id }).from(attendees)
        .where(and(eq(attendees.ownerId, event.ownerId), eq(attendees.email, email))).limit(1);
      let attendeeId: number;
      if (attendeeRows[0]) {
        attendeeId = attendeeRows[0].id;
        await tx.update(attendees).set({ fullName: input.fullName, phone: input.phone || "" }).where(eq(attendees.id, attendeeId));
      } else {
        const [createdAttendee] = await tx.insert(attendees).values({
          ownerId: event.ownerId,
          fullName: input.fullName,
          email,
          phone: input.phone || "",
        }).$returningId();
        attendeeId = createdAttendee.id;
      }
      const customAnswers = JSON.stringify(input.customAnswers ?? {});
      if (event.type === "workshop") {
        const workshopRows = await tx.select().from(workshops).where(eq(workshops.eventId, event.id)).limit(1);
        const workshop = workshopRows[0];
        if (!workshop) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Workshop setup is incomplete." });
        const [previous] = await tx.select({ id: workshopParticipants.id, status: workshopParticipants.status }).from(workshopParticipants)
          .where(and(eq(workshopParticipants.workshopId, workshop.id), eq(workshopParticipants.attendeeId, attendeeId))).limit(1);
        if (previous && previous.status !== "cancelled") throw new TRPCError({ code: "CONFLICT", message: "This email is already registered for the workshop." });
        const [total] = await tx.select({ total: count() }).from(workshopParticipants)
          .where(and(eq(workshopParticipants.workshopId, workshop.id), ne(workshopParticipants.status, "cancelled")));
        if ((total?.total ?? 0) >= workshop.maxParticipants) throw new TRPCError({ code: "BAD_REQUEST", message: "This workshop is full." });
        const ticketCode = makeTicketCode();
        const paymentStatus: "unpaid" | "waived" = Number(workshop.materialCost) > 0 ? "unpaid" : "waived";
        const values = {
          status: "confirmed" as const,
          paymentStatus,
          ticketCode,
          registeredAt: now,
          comments: input.comments || null,
          customAnswers,
          checkedInAt: null,
        };
        if (previous) await tx.update(workshopParticipants).set(values).where(eq(workshopParticipants.id, previous.id));
        else await tx.insert(workshopParticipants).values({ workshopId: workshop.id, attendeeId, ...values });
        return {
          ticketCode,
          eventTitle: event.title,
          status: "confirmed" as const,
          recipient: email,
          fullName: input.fullName,
          eventStartsAt: event.startsAt,
          eventVenue: event.venue,
        };
      }
      const [previous] = await tx.select({ id: registrations.id, status: registrations.status }).from(registrations)
        .where(and(eq(registrations.eventId, event.id), eq(registrations.attendeeId, attendeeId))).limit(1);
      if (previous && previous.status !== "cancelled") throw new TRPCError({ code: "CONFLICT", message: "This email is already registered for the event." });
      const [total] = await tx.select({ total: count() }).from(registrations)
        .where(and(eq(registrations.eventId, event.id), ne(registrations.status, "cancelled")));
      if ((total?.total ?? 0) >= event.capacity) throw new TRPCError({ code: "BAD_REQUEST", message: "This event is full." });
      const ticketCode = makeTicketCode();
      const values = {
        status: "confirmed" as const,
        paymentStatus: "waived" as const,
        ticketCode,
        registeredAt: now,
        comments: input.comments || null,
        customAnswers,
        checkedInAt: null,
      };
      if (previous) await tx.update(registrations).set(values).where(eq(registrations.id, previous.id));
      else await tx.insert(registrations).values({ eventId: event.id, attendeeId, ...values });
      return {
        ticketCode,
        eventTitle: event.title,
        status: "confirmed" as const,
        recipient: email,
        fullName: input.fullName,
        eventStartsAt: event.startsAt,
        eventVenue: event.venue,
      };
    });
    const emailDelivery = await sendRegistrationConfirmation(confirmation);
    return {
      ticketCode: confirmation.ticketCode,
      eventTitle: confirmation.eventTitle,
      status: confirmation.status,
      emailDelivery,
    };
  }),

  registrationList: protectedProcedure.query(({ ctx }) => listRegistrations(ctx.user.id)),

  updateRegistration: protectedProcedure.input(z.object({
    id: z.number().int().positive(),
    itemType: z.enum(["event", "workshop"]),
    status: z.enum(["confirmed", "pending", "cancelled"]).optional(),
    paymentStatus: z.enum(["unpaid", "paid", "refunded", "waived"]).optional(),
    notes: z.string().max(2500).optional(),
    checkedIn: z.boolean().optional(),
  })).mutation(async ({ ctx, input }) => {
    const db = await requireDb();
    const existing = await getOwnedRegistration(ctx.user.id, input.itemType, input.id);
    if (!existing) throw new TRPCError({ code: "NOT_FOUND", message: "Registration not found." });
    const resultingStatus = input.status ?? existing.status;
    if (input.checkedIn && resultingStatus !== "confirmed") throw new TRPCError({ code: "BAD_REQUEST", message: "Only confirmed attendees can be checked in." });
    const patch: Record<string, unknown> = {};
    if (input.status !== undefined) patch.status = input.status;
    if (input.paymentStatus !== undefined) patch.paymentStatus = input.paymentStatus;
    if (input.notes !== undefined) patch.notes = input.notes;
    if (input.checkedIn !== undefined) patch.checkedInAt = input.checkedIn ? new Date() : null;
    if (input.status === "cancelled") patch.checkedInAt = null;
    if (input.status !== undefined) {
      await db.transaction(async (tx) => {
        await tx.select({ id: events.id }).from(events).where(eq(events.id, existing.eventId)).limit(1).for("update");
        const currentRows = input.itemType === "event"
          ? await tx.select({ status: registrations.status }).from(registrations).where(eq(registrations.id, input.id)).limit(1)
          : await tx.select({ status: workshopParticipants.status }).from(workshopParticipants).where(eq(workshopParticipants.id, input.id)).limit(1);
        if (!currentRows[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Registration not found." });
        if (currentRows[0].status === "cancelled" && input.status !== "cancelled") {
          let activeTotal: number;
          if (input.itemType === "event") {
            const [total] = await tx.select({ total: count() }).from(registrations).where(and(eq(registrations.eventId, existing.eventId), ne(registrations.status, "cancelled")));
            activeTotal = total?.total ?? 0;
          } else {
            const [workshop] = await tx.select({ id: workshops.id }).from(workshops).where(eq(workshops.eventId, existing.eventId)).limit(1);
            if (!workshop) throw new TRPCError({ code: "NOT_FOUND", message: "Workshop not found." });
            const [total] = await tx.select({ total: count() }).from(workshopParticipants).where(and(eq(workshopParticipants.workshopId, workshop.id), ne(workshopParticipants.status, "cancelled")));
            activeTotal = total?.total ?? 0;
          }
          if (activeTotal >= existing.capacity) throw new TRPCError({ code: "BAD_REQUEST", message: "This event or workshop is at capacity; the registration cannot be reactivated." });
        }
        if (input.itemType === "event") await tx.update(registrations).set(patch).where(eq(registrations.id, input.id));
        else await tx.update(workshopParticipants).set(patch).where(eq(workshopParticipants.id, input.id));
      });
    } else if (Object.keys(patch).length) {
      if (input.itemType === "event") await db.update(registrations).set(patch).where(eq(registrations.id, input.id));
      else await db.update(workshopParticipants).set(patch).where(eq(workshopParticipants.id, input.id));
    }
    return { success: true };
  }),

  bulkUpdate: protectedProcedure.input(z.object({
    items: z.array(z.object({ id: z.number().int().positive(), itemType: z.enum(["event", "workshop"]) })).min(1).max(100),
    status: z.enum(["confirmed", "pending", "cancelled"]),
  })).mutation(async ({ ctx, input }) => {
    const db = await requireDb();
    const uniqueItems = [...new Map(input.items.map((item) => [`${item.itemType}:${item.id}`, item])).values()];
    return db.transaction(async (tx) => {
      let updated = 0;
      for (const item of uniqueItems) {
        const rows = item.itemType === "event"
          ? await tx.select({ id: registrations.id, status: registrations.status, eventId: events.id, capacity: events.capacity }).from(registrations).innerJoin(events, eq(registrations.eventId, events.id)).where(and(eq(registrations.id, item.id), eq(events.ownerId, ctx.user.id))).limit(1)
          : await tx.select({ id: workshopParticipants.id, status: workshopParticipants.status, eventId: events.id, capacity: workshops.maxParticipants }).from(workshopParticipants).innerJoin(workshops, eq(workshopParticipants.workshopId, workshops.id)).innerJoin(events, eq(workshops.eventId, events.id)).where(and(eq(workshopParticipants.id, item.id), eq(events.ownerId, ctx.user.id))).limit(1);
        const existing = rows[0];
        if (!existing) continue;
        await tx.select({ id: events.id }).from(events).where(eq(events.id, existing.eventId)).limit(1).for("update");
        const currentRows = item.itemType === "event"
          ? await tx.select({ status: registrations.status }).from(registrations).where(eq(registrations.id, item.id)).limit(1)
          : await tx.select({ status: workshopParticipants.status }).from(workshopParticipants).where(eq(workshopParticipants.id, item.id)).limit(1);
        if (!currentRows[0]) continue;
        if (currentRows[0].status === "cancelled" && input.status !== "cancelled") {
          let activeTotal: number;
          if (item.itemType === "event") {
            const [total] = await tx.select({ total: count() }).from(registrations).where(and(eq(registrations.eventId, existing.eventId), ne(registrations.status, "cancelled")));
            activeTotal = total?.total ?? 0;
          } else {
            const [workshop] = await tx.select({ id: workshops.id }).from(workshops).where(eq(workshops.eventId, existing.eventId)).limit(1);
            if (!workshop) continue;
            const [total] = await tx.select({ total: count() }).from(workshopParticipants).where(and(eq(workshopParticipants.workshopId, workshop.id), ne(workshopParticipants.status, "cancelled")));
            activeTotal = total?.total ?? 0;
          }
          if (activeTotal >= existing.capacity) throw new TRPCError({ code: "BAD_REQUEST", message: "One or more registrations could not be confirmed because the offering is at capacity." });
        }
        const patch = input.status === "cancelled" ? { status: input.status, checkedInAt: null } : { status: input.status };
        if (item.itemType === "event") await tx.update(registrations).set(patch).where(eq(registrations.id, item.id));
        else await tx.update(workshopParticipants).set(patch).where(eq(workshopParticipants.id, item.id));
        updated += 1;
      }
      return { updated };
    });
  }),

  analytics: protectedProcedure.query(async ({ ctx }) => {
    const [workspace, rows] = await Promise.all([listWorkspace(ctx.user.id), listRegistrations(ctx.user.id)]);
    const now = new Date();
    const active = rows.filter((row) => row.status !== "cancelled");
    const monthly = Array.from({ length: 12 }, (_, index) => {
      const month = new Date(now.getFullYear(), now.getMonth() - (11 - index), 1);
      const key = `${month.getFullYear()}-${String(month.getMonth() + 1).padStart(2, "0")}`;
      const registrationsInMonth = active.filter((row) => `${row.registeredAt.getFullYear()}-${String(row.registeredAt.getMonth() + 1).padStart(2, "0")}` === key);
      const checkInsInMonth = active.filter((row) => row.checkedInAt && `${row.checkedInAt.getFullYear()}-${String(row.checkedInAt.getMonth() + 1).padStart(2, "0")}` === key);
      return { key, label: month.toLocaleDateString("en-US", { month: "short" }), registrations: registrationsInMonth.length, checkIns: checkInsInMonth.length };
    });
    return {
      monthly,
      events: workspace.map((event) => ({
        id: event.id,
        title: event.title,
        type: event.type,
        status: event.status,
        capacity: event.capacity,
        registrations: event.registrationCount,
        checkIns: event.checkInCount,
        utilization: event.capacity ? Math.min(100, Math.round(event.registrationCount / event.capacity * 100)) : 0,
      })).sort((a, b) => b.registrations - a.registrations),
      totals: {
        registrations: active.length,
        checkIns: active.filter((row) => row.checkedInAt).length,
        publishedEvents: workspace.filter((event) => event.status === "published").length,
        attendanceRate: active.length ? Math.round(active.filter((row) => row.checkedInAt).length / active.length * 100) : 0,
      },
    };
  }),
});
