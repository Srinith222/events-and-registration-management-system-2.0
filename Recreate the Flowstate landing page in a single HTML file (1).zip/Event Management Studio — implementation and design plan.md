# Event Management Studio — implementation and design plan

## Product scope

Build a complete event and workshop registration studio. The organizer is the authenticated host account **srinithcm@gmail.com**; only that signed-in identity can use the management workspace. Visitors can discover public, published events and register without creating an account. The public root page is the event calendar and organizer tools live under `/studio`.

The organizer workspace consists of a dashboard, event/workshop directory and detail pages, registration list, check-in console, analytics/reporting, and settings. The dashboard and reports are derived from actual workspace records, with useful zero-data states instead of simulated attendance. CSV is the export format. Registration is confirmation-only; there is no payment gateway, and any workshop materials/payment state is managed manually.

After a successful MySQL registration commit, automatically send the attendee a confirmation with the event details and ticket code through the approved Gmail sender. If Gmail has not been securely configured or delivery fails, keep the successful registration and report truthfully that email was not delivered. Use the built-in `gpt-5-nano` model only to generate one generic, warm greeting sentence; never send attendee name, email, answers, comments, ticket code, or other personal data to the model. Do not send test email or write/delete attendee data during validation.

## Implementation approach

- Use the initialized React + TypeScript frontend, Express server, typed tRPC API, Drizzle ORM, managed MySQL database, and Manus OAuth/session helpers. Reuse starter authentication and server context rather than introducing another identity system.
- Enforce owner identity on the server using an authenticated owner-only procedure keyed to the verified account email, promote that account to the existing admin role on OAuth user sync, and protect every organizer query/mutation. Keep the public calendar and event invitation read-only except for the narrow registration mutation.
- Model workshops as event records with a normalized workshop-detail row. Store attendees as contacts scoped to their organizer. Regular event registrations reference events and attendees; workshop participation rows connect workshop details and attendees. Use unique attendee/offer relationships, indexed lookups, foreign keys, and a row lock around capacity enforcement during public registration.
- Keep registration fields, public form validation, check-in timestamps, notes, status, payment tracking, reporting queries, and CSV export aligned from this shared data model. Avoid demo activity or fabricated metrics.
- After the registration transaction commits, use Nodemailer over Gmail SMTP only when `GMAIL_APP_PASSWORD` is securely configured. Send a plain-text message from `srinithcm@gmail.com` with attendee-specific ticket details. Use `gpt-5-nano` via the managed `invokeLLM` helper for only a generic greeting; on AI failure use a fixed fallback. Do not block, roll back, or misrepresent registration based on email delivery.
- Use Lucide icons, Recharts charts, Framer Motion for restrained motion, and the starter's existing Sonner notifications and dialog primitives. Provide desktop/mobile layouts, clear loading/error/empty states, keyboardable controls, and a reduced-motion preference.
- Serve the app on the initialized managed React/Express runtime and keep `client/public/manus-routes.json` synchronized with organizer and public pages. Retain managed server/database services and keep auto-publication disabled.

## Project structure

- `client/src/App.tsx` — public/owner route separation; public directory at `/` and owner studio at `/studio`.
- `client/src/components/AppLayout.tsx` — owner-only studio shell, auth gate, navigation, profile, and global search.
- `client/src/components/EventEditorDialog.tsx`, `EventCard.tsx`, `Modal.tsx`, and `StudioUI.tsx` — reusable event forms, directory items, dialogs, status badges, and view states.
- `client/src/pages/` — public event directory, owner dashboard, event directory/detail, registrations, check-in, analytics, settings, public invitation, and registration pages.
- `client/src/lib/` and `client/src/types.ts` — tRPC/date/CSV helpers and inferred shared types.
- `client/src/index.css`, `client/index.html`, and `client/public/gather-mark.svg` — interface themes, font metadata, and brand mark.
- `client/public/manus-routes.json` — route manifest for every page.
- `drizzle/schema.ts`, `drizzle/relations.ts`, and generated migrations — users, events, workshops, attendees, registrations, and workshop participation.
- `server/eventRouter.ts` — owner-guarded management APIs plus published public discovery and registration.
- `server/_core/registrationMail.ts` — secure, Gmail-gated confirmation delivery and isolated AI greeting generation.
- `server/routers.ts` — mounts typed procedures into the root router.
- `shared/const.ts` — the fixed organizer account identity.
- `TODO.md` — outcome-level delivery criteria and progress.

## Visual direction

The user asked for a different design because the dark-glass site felt AI-generated. Replace that direction rather than layering more glass onto it. Preserve Gather, all real data, owner/public routes, and current registration flows.

### Design alternatives

- **Fieldnotes at the Table — 0.07:** A considered independent-event journal in warm paper, pine ink, Fraunces headlines, and small persimmon folio marks.
- **Backstage Ledger — 0.04:** A compact production-office interface in slate, ruled schedules, monospace labels, and sharp ticket-orange status cues.
- **Pavilion at Noon — 0.06:** An airy gallery program in chalk, olive, and mineral blue with a more architectural type scale.

### Chosen style: Fieldnotes at the Table

**Design Movement:** Contemporary editorial design for an independent cultural journal or printed event programme—quiet, tactile, and highly legible rather than glossy or generically SaaS.

**Core Principles:** Let typography and spacing do the work; make the next event the dashboard's editorial lead; treat every count as actionable; use color for meaning and never as ambient decoration.

**Color Philosophy:** The default Fieldnotes palette uses warm paper **#F5F1E8**, card stock **#FFFCF6**, pine ink **#263C32**, and persimmon **#C65B3E** for actions and date marks. Organizers may switch app-wide to Orchard (sage canvas, forest-green action color) or Harbor (blue-gray canvas, deep teal action color with copper secondary marks). All three retain legible dark ink, restrained status colors, and ruled separators; palette choice is stored on the device.

**Layout Paradigm:** Give the navigation rail a prominent Gather wordmark that reads at a glance; give the main workspace a broad editorial title and a responsive 3D welcome scene before the asymmetric “next event” feature, ruled key figures, and two-column rhythm of follow-ups, recent guests, and capacity watch. Use breathing room instead of centered card grids. Public invitations get a poster-like title, one restrained event image, and a simple registration column.

**Signature Elements:** Small numbered folio labels for dashboard sections; date stamps in a persimmon square; thin ledger rules and a single hand-drawn-style circular accent around the next event's day.

**Interaction Philosophy:** Calm, quick, and purposeful. Use crisp focus states, clear active navigation, direct action labels, and deliberate motion in the supplied 3D scene; keep color contrast high and never hide status in decoration. A compact dashboard palette menu changes the whole workspace and remembers the choice. Every visible dashboard button must navigate, open a useful dialog, copy a real invitation with feedback, apply a filter, or change the selected palette—never act as decorative chrome.

**Animation:** Short 160–220 ms opacity/position transitions; reveal the page heading and one feature in sequence, not every card word by word. Animate chart entry and capacity fill once. Avoid floating ornaments, ambient glow, blur, bounce, and looping motion. Respect both the in-app reduced-motion preference and `prefers-reduced-motion`.

**Typography System:** Fraunces for editorial display headings and the Gather wordmark; DM Sans for interface text, labels, and controls; IBM Plex Mono only for ticket codes, tiny folio numerals, and date metadata. Use a restrained size range and tabular figures for metrics.

**Brand Essence:** The welcoming event office for organizers who want every gathering to feel considered. Personality: **grounded, curious, hospitable**.

**Brand Voice:** Human, direct, and grounded in the work of hosting. Example lines: “Your next date is set.” / “A few guests are waiting for your reply.”

**Wordmark & Logo:** Keep the lowercase `gather.` name, set in Fraunces, and replace the generic glossy calendar badge with a simple persimmon folio mark bearing a lowercase `g` and a small cut-corner detail.

**Signature Brand Color:** Gather persimmon **#C65B3E**.

## Exact ThreeUI component integration

Use the user's explicitly configured `<GalleryHeading />` from `@designcodeio/threeui@1.2.0` with its `style.css` in both the public calendar and organizer dashboard hero. Keep `variant="rising-diagonal"` (Matte Rise), `mode="dark"`, `font="sans"`, `weight="400"`, `headlineSize={1.15}`, `hue={0}`, `saturation={1.00}`, and `brightness={1.00}` exactly as specified. The package's decoded embedded GalleryHeading HTML has been verified byte-for-byte against the supplied canonical source SHA-256 `8e42d2d5b4971bfc4d3c485112c3c51909e20a61b8842bc0dcd8db3ffe2d253a`; keep the animation in its isolated canvas iframe and verify it renders at desktop and mobile sizes.

## Main workspace and MNC events calendar

Make the Gather brand larger and more legible on the organizer taskbar/sidebar and its compact mobile header. Keep the owner dashboard editorial, responsive, and fast to scan, with the supplied 3D GalleryHeading as a distinct welcome/brand scene and the real next published event as the main operational focus. Add a curated company-events section for up to eight officially sourced future events/workshops from Microsoft, Google/Google Cloud, Amazon Web Services, IBM, and Oracle, for India or online, dated 2026-11-02 through 2027-01-31. Show the exact title, date/time and timezone, format, venue/platform, clear short description, official event page, official registration page, and fee/capacity only when officially stated. Sort earliest start first. Mark these as externally organized; the call to action must lead to the company's registration page, not Gather's attendee form. Never invent details or create fake attendee records. Prepare the exact listing payload and require the user's final confirmation before public deployment.

## Project constraints

The selected database is shared by Preview and production; validate through non-destructive reads and do not seed or delete user records. Do not send test email during validation. No payment gateway is configured. Never expose private attendee data in public responses or send it to the AI helper. Gmail secrets must be entered only through the secure Webdev input card; never print or store them in source files. Auto-publication is disabled; checkpoint code normally and publish the exact externally sourced listings only after the user's final confirmation.
