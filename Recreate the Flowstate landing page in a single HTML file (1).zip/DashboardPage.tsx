import { useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { GalleryHeading } from "@designcodeio/threeui";
import {
  ArrowDownRight, ArrowRight, CalendarDays, CalendarPlus, Check,
  CheckCheck, ChevronDown, Clock3, Copy, ListChecks, MapPin, Palette,
  TicketCheck, Users,
} from "lucide-react";
import {
  Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { toast } from "sonner";
import { EventEditorDialog } from "@/components/EventEditorDialog";
import { EmptyState, ErrorState, LoadingState, PageMotion, SectionHeading, StatusBadge } from "@/components/StudioUI";
import { trpc } from "@/lib/trpc";
import { formatDate, initials } from "@/lib/format";
import { useAuth } from "@/_core/hooks/useAuth";
import { useTheme, type Theme } from "@/contexts/ThemeContext";

const paletteChoices: { id: Theme; name: string; descriptor: string }[] = [
  { id: "fieldnotes", name: "Fieldnotes", descriptor: "Paper · persimmon" },
  { id: "orchard", name: "Orchard", descriptor: "Sage · forest" },
  { id: "harbor", name: "Harbor", descriptor: "Mist · deep teal" },
];

const chartPalettes: Record<Theme, { primary: string; secondary: string; rule: string; surface: string; ink: string; muted: string }> = {
  fieldnotes: { primary: "#C65B3E", secondary: "#718B72", rule: "#E7E1D7", surface: "#FFFCF6", ink: "#263C32", muted: "#77796F" },
  orchard: { primary: "#557450", secondary: "#BB843A", rule: "#DFE4D8", surface: "#FBFCF7", ink: "#2D4031", muted: "#6F796D" },
  harbor: { primary: "#3E7182", secondary: "#C17A50", rule: "#DDE4E5", surface: "#FCFCF9", ink: "#2C4249", muted: "#707D80" },
};

function number(value: number) {
  return new Intl.NumberFormat("en-US").format(value);
}

export default function DashboardPage() {
  const [createOpen, setCreateOpen] = useState(false);
  const appearanceRef = useRef<HTMLDetailsElement>(null);
  const query = trpc.events.overview.useQuery(undefined, { staleTime: 30_000 });
  const user = useAuth().user;
  const { theme, setTheme } = useTheme();
  const chartColors = chartPalettes[theme] ?? chartPalettes.fieldnotes;
  const selectedPalette = paletteChoices.find((choice) => choice.id === theme) || paletteChoices[0];
  const data = query.data;
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const firstName = user?.name?.split(" ")[0] || "there";
  const today = new Date();

  useEffect(() => {
    const closeOnOutsidePointer = (event: PointerEvent) => {
      const picker = appearanceRef.current;
      if (picker && event.target instanceof Node && !picker.contains(event.target)) picker.open = false;
    };
    document.addEventListener("pointerdown", closeOnOutsidePointer);
    return () => document.removeEventListener("pointerdown", closeOnOutsidePointer);
  }, []);

  if (query.isLoading) return <PageMotion><LoadingState label="Opening your studio ledger…" /></PageMotion>;
  if (query.error || !data) return <ErrorState message={query.error?.message || "Your dashboard could not be loaded."} onRetry={() => query.refetch()} />;

  const nextEvent = data.upcoming[0];
  const nextEventDate = nextEvent ? new Date(nextEvent.startsAt) : null;
  const capacityEvents = data.popularEvents
    .filter((event) => event.status === "published")
    .sort((a, b) => b.registrationCount / Math.max(b.capacity, 1) - a.registrationCount / Math.max(a.capacity, 1))
    .slice(0, 3);
  const metrics = [
    { label: "Guests on the list", value: number(data.totals.registrations), note: "Active registrations", icon: Users },
    { label: "Awaiting review", value: number(data.totals.pendingRegistrations), note: data.totals.pendingRegistrations ? "Needs a look from you" : "Nothing waiting", icon: ListChecks, alert: data.totals.pendingRegistrations > 0 },
    { label: "Live invitations", value: number(data.totals.published), note: `${number(data.totals.events)} in your workspace`, icon: CalendarDays },
    { label: "Guests welcomed", value: number(data.totals.checkIns), note: `${data.totals.attendanceRate}% of confirmed guests`, icon: CheckCheck },
  ];

  const copyInvitation = async () => {
    if (!nextEvent) return;
    try {
      await navigator.clipboard.writeText(`${window.location.origin}/event/${nextEvent.slug}`);
      toast.success("Invitation link copied.");
    } catch {
      toast.error("Copying is unavailable in this browser.");
    }
  };

  return <PageMotion className="dashboard-page">
    <header className="dashboard-intro dashboard-intro-immersive">
      <div className="dashboard-intro-copy">
        <p className="folio-kicker"><span className="folio-number">01</span> THE EVENT OFFICE <i /> {today.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" }).toUpperCase()}</p>
        <h1>{greeting}, {firstName}<span className="title-stop">.</span></h1>
        <p className="page-intro-copy">The next date, the guest list, and anything that needs a reply.</p>
      </div>
      <div className="dashboard-intro-scene">
        <GalleryHeading
          variant="rising-diagonal"
          mode="dark"
          font="sans"
          weight="400"
          headlineSize={1.15}
          hue={0}
          saturation={1.00}
          brightness={1.00}
        />
        <span className="dashboard-scene-caption" aria-hidden="true">GATHER&nbsp; / &nbsp;THE HOST STUDIO</span>
      </div>
      <div className="dashboard-actions dashboard-main-actions">
        <details className="dashboard-theme-switcher" ref={appearanceRef}>
          <summary className="button button-secondary" aria-label={`Choose appearance. Current theme: ${selectedPalette.name}`} title={`Appearance: ${selectedPalette.name}`}>
            <Palette size={16} aria-hidden="true" /><span>Appearance</span><ChevronDown size={13} aria-hidden="true" />
          </summary>
          <div className="theme-options">
            <p className="theme-options-title">CHOOSE YOUR STUDIO LOOK</p>
            {paletteChoices.map((choice) => <button key={choice.id} type="button" className={`theme-choice ${theme === choice.id ? "selected" : ""}`} aria-pressed={theme === choice.id} onClick={() => { setTheme(choice.id); appearanceRef.current?.removeAttribute("open"); }}>
              <span className={`theme-swatch theme-swatch-${choice.id}`} aria-hidden="true"><i/><i/><i/></span>
              <span className="theme-choice-copy"><strong>{choice.name}</strong><small>{choice.descriptor}</small></span>
              {theme === choice.id && <Check size={15} aria-hidden="true" />}
            </button>)}
            <p className="theme-options-footnote">Saved on this device · applies throughout Gather</p>
          </div>
        </details>
        <Link href="/check-in" className="button button-secondary"><TicketCheck size={16} aria-hidden="true" /> Check-in desk</Link>
        <button type="button" className="button button-primary create-event-button" onClick={() => setCreateOpen(true)}><CalendarPlus size={16} aria-hidden="true" /> New event</button>
      </div>
    </header>

    {nextEvent && nextEventDate ? <motion.section className="next-gathering-card" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.24 }}>
      <div className="next-gathering-copy">
        <p className="section-folio"><span>02</span> NEXT ON THE CALENDAR <i className="live-indicator" /> {nextEvent.type === "workshop" ? "WORKSHOP" : "EVENT"}</p>
        <h2>{nextEvent.title}</h2>
        <p className="next-event-description">{nextEvent.description || "Your invitation is live. Here’s a quick look at the day ahead."}</p>
        <div className="next-event-facts">
          <span><CalendarDays size={15} aria-hidden="true" />{formatDate(nextEvent.startsAt, { weekday: "long", month: "long", day: "numeric" })}</span>
          <span><Clock3 size={15} aria-hidden="true" />{nextEventDate.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}</span>
          <span><MapPin size={15} aria-hidden="true" />{nextEvent.venue || "Location to come"}</span>
        </div>
        <div className="next-event-capacity">
          <div className="capacity-label-line"><span>Places spoken for</span><strong>{number(nextEvent.registrationCount)} <i>/ {number(nextEvent.capacity)}</i></strong></div>
          <div className="editorial-progress" role="progressbar" aria-label="Places filled" aria-valuemin={0} aria-valuemax={nextEvent.capacity} aria-valuenow={Math.min(nextEvent.registrationCount, nextEvent.capacity)}><i style={{ width: `${Math.min(100, Math.round(nextEvent.registrationCount / Math.max(nextEvent.capacity, 1) * 100))}%` }} /></div>
          <small>{number(Math.max(0, nextEvent.capacity - nextEvent.registrationCount))} places left</small>
        </div>
        <div className="next-event-actions">
          <Link href={`/events/${nextEvent.id}`} className="button button-primary">Open event details <ArrowRight size={15} aria-hidden="true" /></Link>
          <button type="button" className="button button-secondary" onClick={copyInvitation}><Copy size={14} aria-hidden="true" /> Copy invitation</button>
        </div>
      </div>
      <div className={`next-event-poster ${nextEvent.coverUrl ? "has-cover" : ""}`}>
        {nextEvent.coverUrl && <img src={nextEvent.coverUrl} alt="" className="next-poster-image" />}
        <span className="poster-imprint">GATHER&nbsp; / &nbsp;{nextEvent.type === "workshop" ? "WORKSHOP" : "EVENT"}</span>
        <div className="poster-date-stamp"><span>{nextEventDate.toLocaleDateString("en-US", { month: "short" }).toUpperCase()}</span><strong>{String(nextEventDate.getDate()).padStart(2, "0")}</strong><small>{nextEventDate.getFullYear()}</small></div>
        <span className="poster-category">{nextEvent.category || "A GATHERING"}</span>
        <span className="poster-corner-mark">g.</span>
      </div>
      {data.upcoming.length > 1 && <div className="later-dates"><span className="later-dates-label">AFTER THAT</span>{data.upcoming.slice(1, 4).map((event) => <Link href={`/events/${event.id}`} key={event.id} className="later-date"><span>{new Date(event.startsAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span><strong>{event.title}</strong><ArrowRight size={13} aria-hidden="true" /></Link>)}</div>}
    </motion.section> : <section className="next-gathering-empty">
      <div className="empty-folio">02<span> / &nbsp; NEXT</span></div>
      <div className="next-empty-copy"><p className="section-folio">THE NEXT DATE IS YOURS TO SET</p><h2>No upcoming gathering yet.</h2><p>Give the next idea a date, a place, and a guest list. We’ll keep it all together here.</p><button type="button" className="button button-primary" onClick={() => setCreateOpen(true)}><CalendarPlus size={16} aria-hidden="true" /> Plan your first event</button></div>
      <div className="empty-calendar-note"><span>ROOM FOR</span><strong>GOOD<br />THINGS</strong><i>gather · together</i></div>
    </section>}

    <section className="dashboard-metrics" aria-label="Workspace numbers">
      <div className="metrics-heading"><span>03 &nbsp; YOUR STUDIO, BY THE NUMBERS</span><span>Live workspace totals</span></div>
      <div className="metrics-row">{metrics.map(({ label, value, note, icon: Icon, alert }, index) => <article className={`metric-cell ${alert ? "metric-alert" : ""}`} key={label}>
        <div className="metric-topline"><span className="metric-folio">0{index + 1}</span><Icon size={16} strokeWidth={1.7} aria-hidden="true" /></div>
        <strong className="metric-value">{value}</strong><span className="metric-label">{label}</span><small>{note}</small>
      </article>)}</div>
    </section>

    <div className="dashboard-editorial-grid dashboard-primary-grid">
      <section className="panel chart-panel">
        <SectionHeading title="Registration rhythm" subtitle="Sign-ups and check-ins, month by month." action={<span className="chart-period">PAST SIX MONTHS</span>} />
        {data.totals.registrations > 0 ? <div className="chart-shell"><ResponsiveContainer width="100%" height="100%"><AreaChart data={data.trend} margin={{ top: 12, right: 10, left: -18, bottom: 0 }}>
          <defs><linearGradient id="registrationFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={chartColors.primary} stopOpacity={0.18}/><stop offset="95%" stopColor={chartColors.primary} stopOpacity={0}/></linearGradient></defs>
          <CartesianGrid strokeDasharray="0" vertical={false} stroke={chartColors.rule} />
          <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{ fill: chartColors.muted, fontSize: 11, fontFamily: "DM Sans" }} dy={9}/>
          <YAxis allowDecimals={false} axisLine={false} tickLine={false} tick={{ fill: chartColors.muted, fontSize: 11, fontFamily: "DM Sans" }} dx={-6}/>
          <Tooltip contentStyle={{ border: `1px solid ${chartColors.rule}`, borderRadius: 4, boxShadow: "0 5px 18px rgba(38,60,50,.08)", fontSize: 12, background: chartColors.surface }} labelStyle={{ fontWeight: 700, color: chartColors.ink, marginBottom: 5 }} cursor={{ stroke: chartColors.muted, strokeDasharray: "3 4" }} />
          <Area type="monotone" dataKey="registrations" name="Registrations" stroke={chartColors.primary} strokeWidth={2.5} fill="url(#registrationFill)" activeDot={{ r: 5, fill: chartColors.surface, stroke: chartColors.primary, strokeWidth: 2 }} animationDuration={650}/>
          <Area type="monotone" dataKey="checkIns" name="Check-ins" stroke={chartColors.secondary} strokeWidth={2} fill="transparent" strokeDasharray="4 5" activeDot={{ r: 4, fill: chartColors.surface, stroke: chartColors.secondary, strokeWidth: 2 }}/>
        </AreaChart></ResponsiveContainer></div> : <div className="chart-empty"><div className="chart-empty-art"><i/><i/><i/><i/><i/><i/></div><div><strong>The first sign-ups will make their mark here.</strong><span>Publish an event and share its invitation link.</span></div></div>}
        <div className="chart-legend"><span><i className="legend-dot legend-persimmon"/>Registrations</span><span><i className="legend-dot legend-sage"/>Check-ins</span><span className="chart-foot-note"><ArrowDownRight size={13} /> Live data from your guest list</span></div>
      </section>
      <section className="panel attention-panel">
        <SectionHeading title="A note for the host" subtitle="Registrations that could use your attention." />
        <div className={`attention-feature ${data.totals.pendingRegistrations ? "has-pending" : "all-clear"}`}>
          <span className="attention-number">{String(data.totals.pendingRegistrations).padStart(2, "0")}</span>
          <div><strong>{data.totals.pendingRegistrations ? `${number(data.totals.pendingRegistrations)} ${data.totals.pendingRegistrations === 1 ? "guest is" : "guests are"} waiting` : "You’re all caught up."}</strong><p>{data.totals.pendingRegistrations ? "Take a moment to review the pending registrations." : "No pending registrations need a reply right now."}</p></div>
        </div>
        <Link href={data.totals.pendingRegistrations ? "/registrations?status=pending" : "/registrations"} className="attention-link">{data.totals.pendingRegistrations ? "Review pending guests" : "Open the guest list"}<ArrowRight size={14} aria-hidden="true" /></Link>
        <div className="attention-note"><CalendarDays size={16} aria-hidden="true" /><span>{number(data.totals.published)} live {data.totals.published === 1 ? "invitation" : "invitations"} are open to guests.</span></div>
      </section>
    </div>

    <div className="dashboard-editorial-grid dashboard-secondary-grid">
      <section className="panel recent-panel">
        <SectionHeading title="Just joined" subtitle="The latest names on your guest lists." action={<Link href="/registrations" className="text-link">All guests <ArrowRight size={14} aria-hidden="true" /></Link>} />
        {data.recentRegistrations.length ? <div className="recent-list">{data.recentRegistrations.slice(0, 5).map((person, index) => <div className="recent-item" key={`${person.itemType}-${person.id}`}>
          <span className={`guest-avatar guest-tone-${index % 5}`}>{initials(person.fullName)}</span><span className="recent-guest"><strong>{person.fullName}</strong><small>{person.eventTitle}</small></span><span className="recent-time">{formatDate(person.registeredAt, { month: "short", day: "numeric" })}</span><StatusBadge status={person.status}/>
        </div>)}</div> : <EmptyState icon={<Users size={20}/>} title="No names on the list yet." description="Guest registrations will appear here as they come in." action={() => setCreateOpen(true)} actionLabel="Plan an event" />}
      </section>
      <section className="panel capacity-panel">
        <SectionHeading title="Room left at the table" subtitle="Published events, sorted by how full they are." action={<Link href="/events" className="text-link">All events <ArrowRight size={14} aria-hidden="true" /></Link>} />
        {capacityEvents.length ? <div className="capacity-list">{capacityEvents.map((event, index) => {
          const filled = Math.min(100, Math.round(event.registrationCount / Math.max(event.capacity, 1) * 100));
          return <div className="capacity-row" key={event.id}><div className="capacity-top"><span>{event.title}</span><b>{filled}<i>%</i></b></div><div className="editorial-progress" role="progressbar" aria-label={`${event.title} capacity`} aria-valuemin={0} aria-valuemax={event.capacity} aria-valuenow={Math.min(event.registrationCount, event.capacity)}><i className={`capacity-fill capacity-fill-${index}`} style={{ width: `${filled}%` }}/></div><div className="capacity-meta"><span>{event.registrationCount} of {event.capacity} places · {event.type === "workshop" ? "Workshop" : "Event"}</span><Link href={`/events/${event.id}`}>Manage <ArrowRight size={12} aria-hidden="true"/></Link></div></div>;
        })}</div> : <div className="capacity-empty"><span><CalendarDays size={18}/></span><p>Once an invitation is live, its guest count will show here.</p><button type="button" className="text-link" onClick={() => setCreateOpen(true)}>Create an event <ArrowRight size={13} aria-hidden="true"/></button></div>}
      </section>
    </div>
    <EventEditorDialog open={createOpen} onClose={() => setCreateOpen(false)} />
  </PageMotion>;
}
