import { relations } from "drizzle-orm";
import {
  decimal,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/** Manus-authenticated workspace organizers. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

/** Common event record; workshops are event records with one workshop detail row. */
export const events = mysqlTable(
  "events",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    slug: varchar("slug", { length: 180 }).notNull().unique(),
    title: varchar("title", { length: 180 }).notNull(),
    description: text("description").notNull(),
    type: mysqlEnum("type", ["event", "workshop"]).default("event").notNull(),
    category: varchar("category", { length: 80 }).notNull().default("Community"),
    startsAt: timestamp("startsAt").notNull(),
    endsAt: timestamp("endsAt").notNull(),
    venue: varchar("venue", { length: 240 }).notNull().default(""),
    format: mysqlEnum("format", ["in_person", "online", "hybrid"]).notNull().default("in_person"),
    capacity: int("capacity").notNull(),
    status: mysqlEnum("status", ["draft", "published", "archived"]).notNull().default("draft"),
    coverUrl: varchar("coverUrl", { length: 1000 }),
    registrationOpensAt: timestamp("registrationOpensAt"),
    registrationClosesAt: timestamp("registrationClosesAt"),
    registrationFields: text("registrationFields"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    ownerStartsIndex: index("events_owner_starts_idx").on(table.ownerId, table.startsAt),
    ownerStatusIndex: index("events_owner_status_idx").on(table.ownerId, table.status),
    ownerTypeIndex: index("events_owner_type_idx").on(table.ownerId, table.type),
  }),
);

/** Workshop-only attributes normalized away from shared event scheduling fields. */
export const workshops = mysqlTable("workshops", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull().unique().references(() => events.id, { onDelete: "cascade" }),
  instructor: varchar("instructor", { length: 160 }).notNull().default(""),
  durationHours: decimal("durationHours", { precision: 6, scale: 2 }).notNull().default("1.00"),
  materialCost: decimal("materialCost", { precision: 10, scale: 2 }).notNull().default("0.00"),
  currency: varchar("currency", { length: 3 }).notNull().default("USD"),
  maxParticipants: int("maxParticipants").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** A contact record is scoped to its organizer; no cross-workspace attendee leakage. */
export const attendees = mysqlTable(
  "attendees",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    fullName: varchar("fullName", { length: 160 }).notNull(),
    email: varchar("email", { length: 320 }).notNull(),
    phone: varchar("phone", { length: 40 }).notNull().default(""),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    ownerEmailUnique: uniqueIndex("attendees_owner_email_unique").on(table.ownerId, table.email),
    ownerNameIndex: index("attendees_owner_name_idx").on(table.ownerId, table.fullName),
  }),
);

/** Registrations for regular events. A contact can register once per event. */
export const registrations = mysqlTable(
  "registrations",
  {
    id: int("id").autoincrement().primaryKey(),
    eventId: int("eventId").notNull().references(() => events.id, { onDelete: "cascade" }),
    attendeeId: int("attendeeId").notNull().references(() => attendees.id, { onDelete: "cascade" }),
    registeredAt: timestamp("registeredAt").defaultNow().notNull(),
    status: mysqlEnum("status", ["confirmed", "pending", "cancelled"]).notNull().default("confirmed"),
    paymentStatus: mysqlEnum("paymentStatus", ["unpaid", "paid", "refunded", "waived"]).notNull().default("waived"),
    ticketCode: varchar("ticketCode", { length: 24 }).notNull().unique(),
    comments: text("comments"),
    notes: text("notes"),
    customAnswers: text("customAnswers"),
    checkedInAt: timestamp("checkedInAt"),
  },
  (table) => ({
    eventAttendeeUnique: uniqueIndex("registrations_event_attendee_unique").on(table.eventId, table.attendeeId),
    eventStatusIndex: index("registrations_event_status_idx").on(table.eventId, table.status),
    registeredAtIndex: index("registrations_registered_at_idx").on(table.registeredAt),
  }),
);

/** Many-to-many attendee participation rows for workshops. */
export const workshopParticipants = mysqlTable(
  "workshop_participants",
  {
    id: int("id").autoincrement().primaryKey(),
    workshopId: int("workshopId").notNull().references(() => workshops.id, { onDelete: "cascade" }),
    attendeeId: int("attendeeId").notNull().references(() => attendees.id, { onDelete: "cascade" }),
    registeredAt: timestamp("registeredAt").defaultNow().notNull(),
    status: mysqlEnum("status", ["confirmed", "pending", "cancelled"]).notNull().default("confirmed"),
    paymentStatus: mysqlEnum("paymentStatus", ["unpaid", "paid", "refunded", "waived"]).notNull().default("waived"),
    ticketCode: varchar("ticketCode", { length: 24 }).notNull().unique(),
    comments: text("comments"),
    notes: text("notes"),
    customAnswers: text("customAnswers"),
    checkedInAt: timestamp("checkedInAt"),
  },
  (table) => ({
    workshopAttendeeUnique: uniqueIndex("workshop_participants_workshop_attendee_unique").on(table.workshopId, table.attendeeId),
    workshopStatusIndex: index("workshop_participants_status_idx").on(table.workshopId, table.status),
    registeredAtIndex: index("workshop_participants_registered_at_idx").on(table.registeredAt),
  }),
);

export const usersRelations = relations(users, ({ many }) => ({
  events: many(events),
  attendees: many(attendees),
}));

export const eventsRelations = relations(events, ({ one, many }) => ({
  owner: one(users, { fields: [events.ownerId], references: [users.id] }),
  workshop: one(workshops),
  registrations: many(registrations),
}));

export const workshopsRelations = relations(workshops, ({ one, many }) => ({
  event: one(events, { fields: [workshops.eventId], references: [events.id] }),
  participants: many(workshopParticipants),
}));

export const attendeesRelations = relations(attendees, ({ one, many }) => ({
  owner: one(users, { fields: [attendees.ownerId], references: [users.id] }),
  registrations: many(registrations),
  workshopParticipations: many(workshopParticipants),
}));

export const registrationsRelations = relations(registrations, ({ one }) => ({
  event: one(events, { fields: [registrations.eventId], references: [events.id] }),
  attendee: one(attendees, { fields: [registrations.attendeeId], references: [attendees.id] }),
}));

export const workshopParticipantsRelations = relations(workshopParticipants, ({ one }) => ({
  workshop: one(workshops, { fields: [workshopParticipants.workshopId], references: [workshops.id] }),
  attendee: one(attendees, { fields: [workshopParticipants.attendeeId], references: [attendees.id] }),
}));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Event = typeof events.$inferSelect;
export type Workshop = typeof workshops.$inferSelect;
export type Attendee = typeof attendees.$inferSelect;
export type Registration = typeof registrations.$inferSelect;
export type WorkshopParticipant = typeof workshopParticipants.$inferSelect;
