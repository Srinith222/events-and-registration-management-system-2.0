import type { inferRouterInputs, inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../server/routers";

export type RouterOutputs = inferRouterOutputs<AppRouter>;
export type RouterInputs = inferRouterInputs<AppRouter>;
export type WorkspaceEvent = RouterOutputs["events"]["workspaceList"][number];
export type RegistrationRow = RouterOutputs["events"]["registrationList"][number];
export type OverviewData = RouterOutputs["events"]["overview"];
export type EventFormInput = RouterInputs["events"]["create"];
export type RegistrationItemType = "event" | "workshop";
export type RegistrationStatus = "confirmed" | "pending" | "cancelled";
