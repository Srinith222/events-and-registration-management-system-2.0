import { useMemo } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Activity, ArrowRight, ArrowUpRight, CalendarDays, Download, TicketCheck, Users } from "lucide-react";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { toast } from "sonner";
import { ErrorState, LoadingState, PageMotion, SectionHeading } from "@/components/StudioUI";
import { trpc } from "@/lib/trpc";
import { downloadCsv } from "@/lib/format";

const palette = ["#4166F5", "#63C3AA", "#B39AF6", "#F2AE83", "#70A2EF", "#E67CA0"];

export default function AnalyticsPage() {
  const query = trpc.events.analytics.useQuery(undefined, { staleTime: 30_000 });
  const registrations = trpc.events.registrationList.useQuery(undefined, { staleTime: 30_000 });
  const data = query.data;
  const top = useMemo(() => data?.events.slice(0, 6) ?? [], [data?.events]);
  const exportReport = () => {
    if (!registrations.data?.length) return;
    downloadCsv("gather-attendance-report.csv", registrations.data.map((row) => ({ attendee: row.fullName, email: row.email, phone: row.phone, event: row.eventTitle, type: row.itemType, status: row.status, paymentStatus: row.paymentStatus, ticketCode: row.ticketCode, registeredAt: row.registeredAt.toISOString(), checkedInAt: row.checkedInAt?.toISOString() || "" })));
    toast.success("Your attendance report is ready.");
  };
  if (query.isLoading) return <PageMotion><LoadingState label="Finding the patterns in your gatherings…"/></PageMotion>;
  if (query.error || !data) return <ErrorState message={query.error?.message || "Analytics could not be loaded."} onRetry={() => query.refetch()}/>;
  const cards = [
    { label: "Total registrations", value: data.totals.registrations, note: "Confirmed guests", icon: Users, color: "blue" },
    { label: "Guest attendance", value: `${data.totals.attendanceRate}%`, note: `${data.totals.checkIns} checked in`, icon: TicketCheck, color: "mint" },
    { label: "Live experiences", value: data.totals.publishedEvents, note: "Open for registration", icon: CalendarDays, color: "violet" },
    { label: "Experience reach", value: data.events.length, note: "Events and workshops", icon: Activity, color: "peach" },
  ];
  return <PageMotion className="analytics-page">
    <div className="page-intro page-intro-compact"><div><p className="eyebrow"><span className="eyebrow-dot"/>SMALL SIGNALS, BIG PICTURE</p><h1>Analytics</h1><p className="page-intro-copy">A clear-eyed view of how your gatherings are growing.</p></div><button className="button button-secondary" onClick={exportReport} disabled={!registrations.data?.length}><Download size={16}/>Download report</button></div>
    <div className="analytics-stat-grid">{cards.map(({ label, value, note, icon: Icon, color }, index) => <motion.div className="analytics-stat panel" key={label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * .05 }}><span className={`stat-icon stat-icon-${color}`}><Icon size={18}/></span><div><small>{label}</small><strong>{value}</strong><span>{note}</span></div><ArrowUpRight size={15} className="analytics-stat-arrow"/></motion.div>)}</div>
    <section className="panel analytics-chart-panel"><SectionHeading title="Registration rhythm" subtitle="Monthly sign-ups and event-day attendance over the past year." action={<span className="chart-period">12 month view</span>}/>
      {data.totals.registrations ? <div className="analytics-chart"><ResponsiveContainer width="100%" height="100%"><AreaChart data={data.monthly} margin={{ top: 16, right: 8, left: -16, bottom: 2 }}><defs><linearGradient id="analyticsFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#4166F5" stopOpacity={.18}/><stop offset="100%" stopColor="#4166F5" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="#edf0f7" strokeDasharray="4 4" vertical={false}/><XAxis dataKey="label" axisLine={false} tickLine={false} tick={{ fill: "#8992a7", fontSize: 11 }}/><YAxis allowDecimals={false} axisLine={false} tickLine={false} tick={{ fill: "#8992a7", fontSize: 11 }}/><Tooltip contentStyle={{ border: "1px solid #e8ebf3", borderRadius: 12, boxShadow: "0 12px 34px rgba(37,48,84,.12)", fontSize: 12 }}/><Area type="monotone" dataKey="registrations" name="Registrations" stroke="#4166F5" strokeWidth={2.5} fill="url(#analyticsFill)" activeDot={{ r: 5 }}/><Area type="monotone" dataKey="checkIns" name="Check-ins" stroke="#63C3AA" strokeWidth={2} fill="transparent" strokeDasharray="5 4"/></AreaChart></ResponsiveContainer></div> : <div className="analytics-empty"><span><Activity size={20}/></span><strong>Your first data point is on its way.</strong><p>As soon as guests register, your trendline will appear here.</p></div>}
      <div className="chart-legend"><span><i className="legend-dot legend-blue"/>Registrations</span><span><i className="legend-dot legend-mint"/>Check-ins</span></div>
    </section>
    <div className="analytics-lower-grid"><section className="panel top-events-panel"><SectionHeading title="Events guests love" subtitle="Sorted by active registrations."/>
      {top.length ? <div className="top-events-chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={top} layout="vertical" margin={{ left: 10, right: 14, top: 4, bottom: 4 }}><CartesianGrid stroke="#eff1f7" strokeDasharray="3 4" horizontal={false}/><XAxis type="number" hide allowDecimals={false}/><YAxis type="category" dataKey="title" width={118} axisLine={false} tickLine={false} tick={{ fill: "#566178", fontSize: 11 }}/><Tooltip cursor={{ fill: "#f5f7fc" }} contentStyle={{ borderRadius: 11, border: "1px solid #e8ebf3", fontSize: 12 }}/><Bar dataKey="registrations" name="Registrations" radius={[0, 6, 6, 0]} barSize={14}>{top.map((item, index) => <Cell key={item.id} fill={palette[index % palette.length]}/>)}</Bar></BarChart></ResponsiveContainer></div> : <div className="analytics-mini-empty">Create an event to see which experiences guests are joining.</div>}
    </section><section className="panel utilization-panel"><SectionHeading title="Capacity & attendance" subtitle="How each published experience is filling."/>{data.events.length ? <div className="utilization-list">{data.events.slice(0, 5).map((event) => <div className="utilization-item" key={event.id}><div className="utilization-name"><span className="utilization-dot" style={{ background: palette[event.id % palette.length] }}/><Link href={`/events/${event.id}`}>{event.title}</Link><span>{event.registrations}/{event.capacity}</span></div><div className="progress-track"><motion.i initial={{ width: 0 }} animate={{ width: `${event.utilization}%` }} transition={{ duration: .65 }}/></div><div className="utilization-foot"><span>{event.type === "workshop" ? "Workshop" : "Event"}</span><b>{event.utilization}% full</b><span>{event.checkIns} arrived</span></div></div>)}</div> : <div className="analytics-mini-empty">Publish an event and this view will tell you how capacity is being used.</div>}</section></div>
    <div className="report-foot"><span><Activity size={14}/>Your analytics are calculated from your organizer workspace data.</span><Link href="/registrations">Review registrations <ArrowRight size={14}/></Link></div>
  </PageMotion>;
}
