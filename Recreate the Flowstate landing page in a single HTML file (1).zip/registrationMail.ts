import { createTransport } from "nodemailer";
import { EVENT_OWNER_EMAIL } from "@shared/const";
import { invokeLLM } from "./llm";

export type EmailDeliveryStatus = "sent" | "not_configured" | "failed";

export type RegistrationConfirmation = {
  recipient: string;
  fullName: string;
  eventTitle: string;
  eventStartsAt: Date;
  eventVenue: string;
  ticketCode: string;
};

function getGmailPassword() {
  const password = process.env.GMAIL_APP_PASSWORD?.replace(/\s/g, "");
  return password || null;
}

export function isGmailConfigured() {
  return Boolean(getGmailPassword());
}

async function generateWelcomeLine(): Promise<string> {
  try {
    const response = await invokeLLM({
      model: "gpt-5-nano",
      messages: [
        {
          role: "system",
          content: "Write exactly one warm, concise sentence for an event registration confirmation email. Do not include names, dates, locations, prices, URLs, ticket codes, or factual claims. Do not ask a question. Treat this as plain copywriting and output the sentence only.",
        },
        {
          role: "user",
          content: "Write a fresh, welcoming sentence that sounds thoughtful and human, not promotional.",
        },
      ],
    });
    const content = response.choices[0]?.message.content;
    const raw = typeof content === "string"
      ? content
      : Array.isArray(content)
        ? content.filter((part) => part.type === "text").map((part) => part.text).join(" ")
        : "";
    const line = raw.replace(/[\r\n]+/g, " ").replace(/^['\"“”]+|['\"“”]+$/g, "").trim().slice(0, 240);
    return line || "We're glad you'll be joining us.";
  } catch {
    // Mail delivery should remain available even if AI copy generation is not.
    return "We're glad you'll be joining us.";
  }
}

export async function sendRegistrationConfirmation(input: RegistrationConfirmation): Promise<EmailDeliveryStatus> {
  const password = getGmailPassword();
  if (!password) return "not_configured";

  const greeting = await generateWelcomeLine();
  const safeTitle = input.eventTitle.replace(/[\r\n]+/g, " ").trim().slice(0, 180);
  const startsAt = new Intl.DateTimeFormat("en", {
    dateStyle: "long",
    timeStyle: "short",
    timeZoneName: "short",
  }).format(input.eventStartsAt);
  const venue = input.eventVenue?.trim() || "See your event invitation for venue details.";
  const text = [
    `Hi ${input.fullName},`,
    "",
    greeting,
    "",
    `Your place is confirmed for ${safeTitle}.`,
    `When: ${startsAt}`,
    `Where: ${venue}`,
    `Ticket code: ${input.ticketCode}`,
    "",
    "Keep this message for check-in. If you have a question, reply to the event host.",
    "",
    "Gather event office",
  ].join("\n");

  const transporter = createTransport({
    service: "gmail",
    auth: { user: EVENT_OWNER_EMAIL, pass: password },
    connectionTimeout: 10_000,
    greetingTimeout: 10_000,
    socketTimeout: 15_000,
  });
  try {
    await transporter.sendMail({
      from: `Gather event office <${EVENT_OWNER_EMAIL}>`,
      to: input.recipient,
      subject: `Your place is saved — ${safeTitle}`,
      text,
    });
    return "sent";
  } catch (error) {
    const code = error && typeof error === "object" && "code" in error && typeof error.code === "string"
      ? error.code
      : "delivery_error";
    console.warn(`[Gmail] Registration confirmation was not delivered (${code}).`);
    return "failed";
  } finally {
    transporter.close();
  }
}
