import { useState } from "react";
import { motion } from "framer-motion";
import { Link, useLocation, useParams } from "wouter";
import { ArrowLeft, ArrowRight, CalendarDays, Check, CheckCircle2, Clipboard, LoaderCircle, LockKeyhole, TicketCheck, Users } from "lucide-react";
import { toast } from "sonner";
import { ErrorState, LoadingState, PageMotion } from "@/components/StudioUI";
import { trpc } from "@/lib/trpc";
import { formatDateRange } from "@/lib/format";

type RegistrationSuccess = { ticketCode: string; eventTitle: string; status: "confirmed"; emailDelivery: "sent" | "not_configured" | "failed" };

export default function PublicRegistrationPage() {
  const { slug = "" } = useParams<{ slug: string }>();
  const [, navigate] = useLocation();
  const eventQuery = trpc.events.getPublicBySlug.useQuery({ slug }, { retry: false });
  const [success, setSuccess] = useState<RegistrationSuccess | null>(null);
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [comments, setComments] = useState("");
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const register = trpc.events.registerPublic.useMutation({
    onSuccess: (result) => {
      setSuccess(result);
      eventQuery.refetch();
      if (result.emailDelivery === "sent") toast.success("Your confirmation email is on its way.");
      else if (result.emailDelivery === "failed") toast.warning("Your place is saved, but the confirmation email could not be delivered.");
    },
    onError: (error) => toast.error(error.message),
  });
  if (eventQuery.isLoading) return <div className="public-loading"><LoadingState label="Preparing your place…"/></div>;
  if (eventQuery.error || !eventQuery.data) return <div className="public-not-found"><Link className="public-back" href="/"><ArrowLeft size={15}/>Gather</Link><ErrorState message={eventQuery.error?.message || "This invitation isn't available."} onRetry={() => eventQuery.refetch()}/></div>;
  const event = eventQuery.data.event;
  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    register.mutate({ slug, fullName, email, phone, comments, customAnswers: answers });
  };
  const copyTicket = async () => { if (!success) return; await navigator.clipboard.writeText(success.ticketCode); toast.success("Your ticket code is copied."); };
  const tone = ["blue", "violet", "mint", "peach"][event.id % 4];

  return <PageMotion className="public-registration-page">
    <header className="public-topbar"><Link href="/" className="public-brand"><span className="public-brand-icon"><CalendarDays size={18}/></span><span>gather<span>.</span></span></Link><span className="public-header-note"><LockKeyhole size={13}/>Your details stay private.</span><span className="registration-step-pill"><span>01</span> YOUR DETAILS</span></header>
    <main className="registration-shell"><Link className="public-back" href={`/event/${event.slug}`}><ArrowLeft size={14}/>Back to the invitation</Link>
      <div className="registration-layout"><section className="registration-main">
        {success ? <div className="registration-success"><motion.div className="success-check" initial={{ scale: .5, rotate: -15, opacity: 0 }} animate={{ scale: 1, rotate: 0, opacity: 1 }} transition={{ type: "spring", stiffness: 240, damping: 17 }}><Check size={31}/></motion.div><p className="eyebrow"><span className="eyebrow-dot"/>YOUR PLACE IS SAVED</p><h1>You're on the list.</h1><p className="success-copy">You're all set for <strong>{success.eventTitle}</strong>. We can't wait to welcome you.</p><div className="ticket-confirmation"><span className="ticket-confirm-icon"><TicketCheck size={20}/></span><span><small>YOUR TICKET CODE</small><strong>{success.ticketCode}</strong></span><button className="button-icon" aria-label="Copy ticket code" onClick={copyTicket}><Clipboard size={16}/></button></div><div className="success-notice"><CheckCircle2 size={17}/><span>Your registration is confirmed. Save your ticket code and show it to the organizer when you arrive.</span></div><button className="button button-primary success-back-button" onClick={() => navigate(`/event/${event.slug}`)}>Back to the event <ArrowRight size={16}/></button><p className="success-email-note">{success.emailDelivery === "sent" ? `A confirmation has been sent to ${email}.` : success.emailDelivery === "failed" ? `Your place is saved, but we couldn't email ${email}. Keep this screen or copy your ticket code and contact the host.` : "Gmail isn't connected yet, so no confirmation email was sent. Keep this screen or copy your ticket code."}</p></div> : <>
          <p className="eyebrow"><span className="eyebrow-dot"/>ONE SMALL STEP, THEN YOU'RE IN</p><h1>Save your<br/><span>place.</span></h1><p className="registration-intro">A few details, and we'll put you on the list.</p>
          {!eventQuery.data.registrationOpen && <div className="registration-closed-alert">Registration has closed or all places have been filled. Please return to the event page for updates.</div>}
          <form className="public-form" onSubmit={submit}>
            <label className="field"><span>Full name<i>*</i></span><input required minLength={2} maxLength={160} autoComplete="name" value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="The name you'd like us to know"/></label>
            <label className="field"><span>Email address<i>*</i></span><input required type="email" maxLength={320} autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com"/><small>We'll send your ticket code here when the host's Gmail connection is ready.</small></label>
            <label className="field"><span>Phone number <small>optional</small></span><input type="tel" maxLength={40} autoComplete="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="A number the organizer can reach you on"/></label>
            {event.registrationFields.map((field) => <label className="field" key={field}><span>{field} <small>optional</small></span><input maxLength={500} value={answers[field] || ""} onChange={(e) => setAnswers((current) => ({ ...current, [field]: e.target.value }))} placeholder="Your answer"/></label>)}
            <label className="field"><span>Anything else? <small>optional</small></span><textarea rows={3} maxLength={2500} value={comments} onChange={(e) => setComments(e.target.value)} placeholder="Dietary needs, questions, or a little note for the host…"/></label>
            <button type="submit" className="button button-primary registration-submit" disabled={!eventQuery.data.registrationOpen || register.isPending}>{register.isPending ? <LoaderCircle size={17} className="spin"/> : <Check size={17}/>}Save my place <ArrowRight size={16}/></button>
            <p className="registration-privacy"><LockKeyhole size={13}/>Your information is stored privately for this organizer and this event.</p>
          </form>
        </>}
      </section>
      <aside className="registration-side"><div className={`registration-cover tone-${tone}${event.coverUrl ? " has-cover" : ""}`}>{event.coverUrl && <img className="cover-image" src={event.coverUrl} loading="lazy" alt=""/>}<span className="art-sun"/><span className="art-line art-line-one"/><span className="art-line art-line-two"/><span className="art-line art-line-three"/><span className="registration-cover-label">YOU'RE INVITED</span><span className="registration-cover-title">{event.title}</span></div><div className="registration-event-card"><span className="event-category">{event.type === "workshop" ? "Workshop" : event.category}</span><h2>{event.title}</h2><p><CalendarDays size={14}/>{formatDateRange(event.startsAt, event.endsAt)}</p><p><Users size={14}/>{eventQuery.data.remainingSeats} places still open</p></div><div className="registration-side-note"><span>✳</span><p>Small gatherings make room for big memories.</p></div></aside></div>
      <footer className="registration-footer"><span>gather<span>.</span> · Made for people, by people.</span><span><LockKeyhole size={12}/>Private and secure</span></footer>
    </main>
  </PageMotion>;
}
