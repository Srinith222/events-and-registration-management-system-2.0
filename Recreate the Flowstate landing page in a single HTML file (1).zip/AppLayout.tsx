import { useEffect, useMemo, useRef, useState } from "react";
import type { ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Link, useLocation } from "wouter";
import {
  ArrowRight, CalendarDays, CalendarPlus, ChartNoAxesCombined,
  ChevronDown, ChevronRight, CircleHelp, ClipboardList, Command,
  LayoutDashboard, LogOut, Menu, Search, ScanLine, Settings2, X,
} from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { EVENT_OWNER_EMAIL } from "@shared/const";
import { trpc } from "@/lib/trpc";
import { initials } from "@/lib/format";
import type { RegistrationRow, WorkspaceEvent } from "@/types";
import { LoadingState } from "@/components/StudioUI";

const navigation = [
  { label: "Overview", href: "/studio", icon: LayoutDashboard },
  { label: "Events & workshops", href: "/events", icon: CalendarDays },
  { label: "Registrations", href: "/registrations", icon: ClipboardList },
  { label: "Check-in", href: "/check-in", icon: ScanLine },
  { label: "Analytics", href: "/analytics", icon: ChartNoAxesCombined },
];

function usePageTitle(path: string) {
  if (path.startsWith("/events/new")) return "Create event";
  if (path.startsWith("/events/")) return "Event details";
  return navigation.find((item) => item.href === path)?.label ?? (path === "/settings" ? "Workspace settings" : "Gather workspace");
}

function QuickSearch({ onNavigate }: { onNavigate: () => void }) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const { data: events = [] } = trpc.events.workspaceList.useQuery(undefined, { staleTime: 45_000 });
  const { data: registrations = [] } = trpc.events.registrationList.useQuery(undefined, { staleTime: 45_000 });
  const [, navigate] = useLocation();

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault(); setOpen(true); setTimeout(() => inputRef.current?.focus(), 0);
      }
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  const normalized = query.trim().toLowerCase();
  const matches = useMemo(() => {
    if (normalized.length < 2) return { events: [] as WorkspaceEvent[], registrations: [] as RegistrationRow[] };
    return {
      events: events.filter((event) => `${event.title} ${event.category} ${event.venue}`.toLowerCase().includes(normalized)).slice(0, 4),
      registrations: registrations.filter((item) => `${item.fullName} ${item.email} ${item.eventTitle} ${item.ticketCode}`.toLowerCase().includes(normalized)).slice(0, 5),
    };
  }, [events, normalized, registrations]);

  const goto = (href: string) => { navigate(href); setQuery(""); setOpen(false); onNavigate(); };

  return <div className={`global-search ${open ? "is-open" : ""}`}>
    <Search size={17} className="search-icon" aria-hidden="true" />
    <input
      ref={inputRef}
      aria-label="Search events, attendees, and registrations"
      placeholder="Search anything…"
      value={query}
      onFocus={() => setOpen(true)}
      onChange={(event) => setQuery(event.target.value)}
      onKeyDown={(event) => { if (event.key === "Enter" && query.trim()) goto(`/events?q=${encodeURIComponent(query.trim())}`); }}
    />
    {!query && <kbd><Command size={11} /> K</kbd>}
    <AnimatePresence>
      {open && <>
        <button className="search-dismiss" aria-label="Close search" onClick={() => setOpen(false)} />
        <motion.div className="search-results" initial={{ opacity: 0, y: 8, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 5, scale: 0.99 }} transition={{ duration: 0.16 }}>
          {!normalized && <p className="search-hint">Type an event, attendee, or ticket code <span>ESC to close</span></p>}
          {normalized.length >= 2 && <>
            {matches.events.length > 0 && <><p className="search-section-title">Events & workshops</p>{matches.events.map((event) => <button className="search-result" key={`e-${event.id}`} onClick={() => goto(`/events/${event.id}`)}><span className="search-result-icon"><CalendarDays size={16} /></span><span><strong>{event.title}</strong><small>{event.type === "workshop" ? "Workshop" : "Event"} · {event.category}</small></span><ArrowRight size={15} /></button>)}</>}
            {matches.registrations.length > 0 && <><p className="search-section-title">Attendees & registrations</p>{matches.registrations.map((item) => <button className="search-result" key={`r-${item.itemType}-${item.id}`} onClick={() => goto(`/registrations?search=${encodeURIComponent(item.email)}`)}><span className="search-avatar">{initials(item.fullName)}</span><span><strong>{item.fullName}</strong><small>{item.eventTitle} · {item.ticketCode}</small></span><ArrowRight size={15} /></button>)}</>}
            {!matches.events.length && !matches.registrations.length && <p className="search-empty">No matching events or registrations.</p>}
            <button className="search-all" onClick={() => goto(`/events?q=${encodeURIComponent(query.trim())}`)}>See all results for “{query.trim()}”<ArrowRight size={14} /></button>
          </>}
        </motion.div>
      </>}
    </AnimatePresence>
  </div>;
}

export function AppLayout({ children }: { children: ReactNode }) {
  const [location, navigate] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [workspaceLabel, setWorkspaceLabel] = useState("Gather studio");
  const { user, logout } = useAuth();
  const pageTitle = usePageTitle(location.split("?")[0]);
  const name = user?.name || user?.email || "Organizer";
  const avatarLetters = initials(name);

  useEffect(() => {
    const syncWorkspaceLabel = () => setWorkspaceLabel(localStorage.getItem("gather-workspace-label") || (user?.name ? `${user.name.split(" ")[0]}'s studio` : "Gather studio"));
    syncWorkspaceLabel();
    window.addEventListener("gather-preferences-changed", syncWorkspaceLabel);
    return () => window.removeEventListener("gather-preferences-changed", syncWorkspaceLabel);
  }, [user?.name]);

  const handleLogout = async () => {
    try { await logout(); } finally { window.location.reload(); }
  };

  const sidebar = <aside className="sidebar">
    <Link href="/studio" className="brand" onClick={() => setMobileOpen(false)}>
      <span className="brand-icon"><span className="brand-monogram">g</span><span className="brand-period">.</span></span>
      <span className="brand-word">gather<span>.</span><small>EVENT OFFICE</small></span>
    </Link>
    <div className="workspace-switcher"><div className="workspace-avatar">G</div><div className="workspace-copy"><span>Workspace</span><strong>{workspaceLabel}</strong></div><ChevronDown size={15} /></div>
    <p className="nav-label">WORKSPACE</p>
    <nav className="primary-nav" aria-label="Main navigation">
      {navigation.map(({ label, href, icon: Icon }) => {
        const active = href === "/" ? location === "/" : location.startsWith(href);
        return <Link key={href} href={href} className={`nav-link ${active ? "active" : ""}`} onClick={() => setMobileOpen(false)}>
          <Icon size={18} strokeWidth={active ? 2.2 : 1.8} /><span>{label}</span>{active && <motion.i layoutId="nav-active" className="nav-indicator" />}
        </Link>;
      })}
    </nav>
    <p className="nav-label nav-label-tools">PREFERENCES</p>
    <Link href="/settings" className={`nav-link ${location === "/settings" ? "active" : ""}`} onClick={() => setMobileOpen(false)}><Settings2 size={18} /><span>Settings</span></Link>
    <div className="sidebar-bottom">
      <div className="sidebar-tip"><span className="tip-spark"><CalendarPlus size={15} /></span><strong>Set the date first.</strong><p>A clear time, place, and capacity make an invitation easier to act on.</p><Link href="/events/new" onClick={() => setMobileOpen(false)}>Create an event <ArrowRight size={13} /></Link></div>
      <button className="sidebar-help" onClick={() => navigate("/settings")}><CircleHelp size={16} />Help & support<ChevronRight size={15} /></button>
      <div className="sidebar-version">GATHER STUDIO <span>v1.0</span></div>
    </div>
  </aside>;

  return <div className="app-frame">
    <div className="desktop-sidebar">{sidebar}</div>
    <AnimatePresence>{mobileOpen && <>
      <motion.button className="mobile-scrim" aria-label="Close navigation" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setMobileOpen(false)} />
      <motion.div className="mobile-sidebar" initial={{ x: -300 }} animate={{ x: 0 }} exit={{ x: -300 }} transition={{ type: "spring", stiffness: 320, damping: 32 }}>{sidebar}<button className="mobile-close" aria-label="Close navigation" onClick={() => setMobileOpen(false)}><X size={18} /></button></motion.div>
    </>}</AnimatePresence>
    <div className="workspace-main">
      <header className="topbar">
        <button className="mobile-menu button-icon" aria-label="Open navigation" onClick={() => setMobileOpen(true)}><Menu size={20} /></button>
        <Link href="/studio" className="mobile-topbar-brand" aria-label="Gather studio">gather<span>.</span></Link>
        <div className="breadcrumb"><span>Workspace</span><ChevronRight size={14} /><strong>{pageTitle}</strong></div>
        <div className="topbar-actions">
          <QuickSearch onNavigate={() => setMobileOpen(false)} />
          <div className="profile-wrap">
            <button className="profile-button" onClick={() => setProfileOpen((value) => !value)} aria-expanded={profileOpen}>
              <span className="profile-avatar">{avatarLetters}</span><span className="profile-name">{name.split(" ")[0]}</span><ChevronDown size={14} />
            </button>
            <AnimatePresence>{profileOpen && <motion.div className="profile-menu" initial={{ opacity: 0, y: 7 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}><div className="profile-menu-user"><strong>{user?.name || "Organizer"}</strong><span>{user?.email || "Signed in"}</span><small className="profile-role">STUDIO OWNER</small></div><button onClick={() => { setProfileOpen(false); navigate("/settings"); }}><Settings2 size={15} />Workspace settings</button><button className="profile-logout" onClick={handleLogout}><LogOut size={15} />Sign out</button></motion.div>}</AnimatePresence>
          </div>
        </div>
      </header>
      <main className="main-content">{children}</main>
      <footer className="app-footer"><span><span className="footer-mark">g.</span> Gather · a good place to get things together.</span><span>Events, invitations, guest lists.</span></footer>
    </div>
  </div>;
}

export function OwnerGate({ children }: { children: ReactNode }) {
  const auth = useAuth();
  const [, navigate] = useLocation();
  if (auth.loading) return <div className="auth-screen"><LoadingState label="Opening your workspace…" /></div>;
  if (!auth.isAuthenticated) {
    return <div className="auth-screen"><motion.div className="auth-card" initial={{ opacity: 0, y: 18, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }}>
      <span className="auth-brand-icon"><CalendarDays size={24} /><span>g.</span></span><p className="eyebrow">OWNER ACCESS</p><h1>The event office is yours.</h1><p className="auth-copy">Sign in with the host account to manage events, workshops, guest lists, and check-in.</p>
      <button className="button button-primary auth-submit" onClick={() => startLogin()}>Sign in as owner <ArrowRight size={17} /></button>
      <p className="auth-footnote">Visitors can browse and register from the public calendar without signing in.</p>
    </motion.div></div>;
  }
  if (auth.user?.email?.trim().toLowerCase() !== EVENT_OWNER_EMAIL.toLowerCase()) {
    const signOut = async () => { try { await auth.logout(); } finally { window.location.reload(); } };
    return <div className="auth-screen"><motion.div className="auth-card visitor-access-card" initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }}>
      <span className="auth-brand-icon"><CalendarDays size={24} /><span>g.</span></span><p className="eyebrow">VISITOR ACCESS</p><h1>The studio belongs to the host.</h1><p className="auth-copy">You're signed in with a visitor account. Public events and workshops are open to browse and register for without an account.</p>
      <button className="button button-primary auth-submit" onClick={() => navigate("/")}>Browse events <ArrowRight size={17} /></button>
      <button className="visitor-switch-account" onClick={signOut}><LogOut size={15}/>Sign out to switch to the owner account</button>
    </motion.div></div>;
  }
  return <>{children}</>;
}
