import React, { createContext, useContext, useEffect, useState } from "react";

export type Theme = "fieldnotes" | "orchard" | "harbor";

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  toggleTheme?: () => void;
  switchable: boolean;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

interface ThemeProviderProps {
  children: React.ReactNode;
  defaultTheme?: Theme;
  switchable?: boolean;
}

function readSavedTheme(defaultTheme: Theme): Theme {
  try {
    const value = localStorage.getItem("gather-theme");
    return value === "fieldnotes" || value === "orchard" || value === "harbor" ? value : defaultTheme;
  } catch {
    return defaultTheme;
  }
}

export function ThemeProvider({
  children,
  defaultTheme = "fieldnotes",
  switchable = true,
}: ThemeProviderProps) {
  const [theme, setTheme] = useState<Theme>(() => switchable ? readSavedTheme(defaultTheme) : defaultTheme);

  useEffect(() => {
    const root = document.documentElement;
    root.dataset.gatherTheme = theme;
    root.classList.remove("dark");
    if (switchable) {
      try { localStorage.setItem("gather-theme", theme); } catch { /* Keep theme changes available for this session. */ }
    }
  }, [theme, switchable]);

  const toggleTheme = switchable
    ? () => setTheme((current) => current === "fieldnotes" ? "orchard" : current === "orchard" ? "harbor" : "fieldnotes")
    : undefined;

  return (
    <ThemeContext.Provider value={{ theme, setTheme, toggleTheme, switchable }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) throw new Error("useTheme must be used within ThemeProvider");
  return context;
}
