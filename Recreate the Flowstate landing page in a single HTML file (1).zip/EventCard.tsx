import { useState } from "react";
import { Link } from "wouter";
import { AnimatePresence, motion } from "framer-motion";
import { Archive, ArrowDownRight, ArrowRight, CalendarClock, Check, Clipboard, Copy, ExternalLink, MoreHorizontal, Pencil, Users } from "lucide-react";
import { toast } from "sonner";
import { StatusBadge } from "@/components/StudioUI";
import { trpc } from "@/lib/trpc";
import { formatDateRange } from "@/lib/format";
import type { WorkspaceEvent } from "@/types";

export function EventCard({ event, onEdit, view = "card" }: { event: WorkspaceEvent; onEdit: (event: WorkspaceEvent) => void; view?: "card" | "row" }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const utils = trpc.useUtils();
  const setStatus = trpc.events.setStatus.useMutation({
    onSuccess: async () => { await Promise.all([utils.events.workspaceList.invalidate(), utils.events.overview.invalidate()]); toast.success("Event status updated."); },
    onError: (error) => toast.error(error.message),
  });
  const duplicate = trpc.events.duplicate.useMutation({
    onSuccess: async () => { await Promise.all([utils.events.workspaceList.invalidate(), utils.events.overview.invalidate()]); toast.success("A fresh draft copy is ready."); },
    onError: (error) => toast.error(error.message),
  });
  const remaining = Math.max(event.capacity - event.registrationCount, 0);
  const progress = Math.min(100, Math.round(event.registrationCount / Math.max(event.capacity, 1) * 100));
  const tones = ["blue", "violet", "mint", "peach"];
  const coverTone = tones[event.id % tones.length];
  const copyLink = async () => {
    await navigator.clipboard.writeText(`${window.location.origin}/event/${event.slug}`);
    toast.success("Public event link copied."); setMenuOpen(false);
  };
  const archive = () => {
    if (window.confirm(`Archive “${event.title}”? It will disappear from the public listings, but its attendee history will stay saved.`)) {
      setStatus.mutate({ id: event.id, status: "archived" });
      setMenuOpen(false);
    }
  };

  if (view === "row") return <motion.div className="event-table-row" layout initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
    <div className={`event-row-art tone-${coverTone}${event.coverUrl ? " has-cover" : ""}`}>{event.coverUrl && <img className="cover-image" src={event.coverUrl} loading="lazy" alt=""/>}<span className="art-sun"/><span className="art-line art-line-one"/><span className="art-line art-line-two"/><CalendarClock size={17} /></div>
    <div className="event-row-title"><Link href={`/events/${event.id}`}><strong>{event.title}</strong></Link><span>{event.category} · {event.type === "workshop" ? "Workshop" : "Event"}</span></div>
    <div className="event-row-date">{formatDateRange(event.startsAt, event.endsAt)}</div>
    <div className="event-row-guests"><Users size={14} />{event.registrationCount}<span>/ {event.capacity}</span></div>
    <div><StatusBadge status={event.status} /></div>
    <EventMenu event={event} open={menuOpen} setOpen={setMenuOpen} onEdit={onEdit} onCopy={copyLink} onArchive={archive} onDuplicate={() => duplicate.mutate({ id: event.id })} onStatus={(status) => setStatus.mutate({ id: event.id, status })} />
  </motion.div>;

  return <motion.article className="event-card" layout initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} whileHover={{ y: -3 }} transition={{ duration: 0.25 }}>
    <Link href={`/events/${event.id}`} className={`event-card-cover tone-${coverTone}${event.coverUrl ? " has-cover" : ""}`}>
      {event.coverUrl && <img className="cover-image" src={event.coverUrl} loading="lazy" alt=""/>}
      <span className="art-sun"/><span className="art-line art-line-one"/><span className="art-line art-line-two"/><span className="art-line art-line-three"/>
      <span className="event-cover-type">{event.type === "workshop" ? "WORKSHOP" : event.category.toUpperCase()}</span>
      <span className="event-cover-date">{new Date(event.startsAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
      <span className="cover-visual-icon">{event.type === "workshop" ? <ArrowDownRight size={21} /> : <CalendarClock size={21} />}</span>
    </Link>
    <div className="event-card-content">
      <div className="event-card-topline"><span className="event-category">{event.type === "workshop" ? "Workshop" : event.category}</span><StatusBadge status={event.status} /></div>
      <Link className="event-card-title" href={`/events/${event.id}`}>{event.title}</Link>
      <p className="event-card-date"><CalendarClock size={14} />{formatDateRange(event.startsAt, event.endsAt)}</p>
      <div className="event-card-progress"><div className="progress-label"><span><Users size={14} />{event.registrationCount} registered</span><span>{remaining} left</span></div><div className="progress-track"><motion.i initial={{ width: 0 }} animate={{ width: `${progress}%` }} transition={{ duration: 0.7, ease: "easeOut" }} /></div></div>
      <div className="event-card-bottom"><span className="event-card-location">{event.venue || (event.format === "online" ? "Online event" : "Location to be announced")}</span><Link className="event-open-link" href={`/events/${event.id}`} aria-label={`Open ${event.title}`}><ArrowRight size={16} /></Link></div>
      <EventMenu event={event} open={menuOpen} setOpen={setMenuOpen} onEdit={onEdit} onCopy={copyLink} onArchive={archive} onDuplicate={() => duplicate.mutate({ id: event.id })} onStatus={(status) => setStatus.mutate({ id: event.id, status })} />
    </div>
  </motion.article>;
}

function EventMenu({ event, open, setOpen, onEdit, onCopy, onArchive, onDuplicate, onStatus }: {
  event: WorkspaceEvent;
  open: boolean;
  setOpen: (value: boolean) => void;
  onEdit: (event: WorkspaceEvent) => void;
  onCopy: () => void;
  onArchive: () => void;
  onDuplicate: () => void;
  onStatus: (status: "draft" | "published" | "archived") => void;
}) {
  return <div className="event-menu-wrap">
    <button className="event-menu-trigger" aria-label={`Actions for ${event.title}`} aria-expanded={open} onClick={(e) => { e.preventDefault(); e.stopPropagation(); setOpen(!open); }}><MoreHorizontal size={19} /></button>
    <AnimatePresence>{open && <motion.div className="event-menu" initial={{ opacity: 0, y: 5, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, scale: 0.98 }}>
      <button onClick={() => { onEdit(event); setOpen(false); }}><Pencil size={14} />Edit details</button>
      {event.status === "published" ? <button onClick={onCopy}><Clipboard size={14} />Copy public link</button> : <button onClick={() => onStatus("published")}><ExternalLink size={14} />Publish event</button>}
      {event.status === "published" && <button onClick={() => onStatus("draft")}><Check size={14} />Move to draft</button>}
      <button onClick={onDuplicate}><Copy size={14} />Duplicate</button>
      {event.status !== "archived" && <button className="danger-menu-item" onClick={onArchive}><Archive size={14} />Archive</button>}
      {event.status === "archived" && <button onClick={() => onStatus("draft")}><Check size={14} />Restore as draft</button>}
    </motion.div>}</AnimatePresence>
  </div>;
}
