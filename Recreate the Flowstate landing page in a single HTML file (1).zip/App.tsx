import { Suspense, lazy, useEffect, useState } from "react";
import { MotionConfig } from "framer-motion";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AppLayout, OwnerGate } from "./components/AppLayout";
const DashboardPage = lazy(() => import("./pages/DashboardPage"));
const EventsPage = lazy(() => import("./pages/EventsPage"));
const EventDetailsPage = lazy(() => import("./pages/EventDetailsPage"));
const RegistrationsPage = lazy(() => import("./pages/RegistrationsPage"));
const CheckInPage = lazy(() => import("./pages/CheckInPage"));
const AnalyticsPage = lazy(() => import("./pages/AnalyticsPage"));
const SettingsPage = lazy(() => import("./pages/SettingsPage"));
const PublicEventsPage = lazy(() => import("./pages/PublicEventsPage"));
const PublicEventPage = lazy(() => import("./pages/PublicEventPage"));
const PublicRegistrationPage = lazy(() => import("./pages/PublicRegistrationPage"));

function RouteLoading({ publicPage = false }: { publicPage?: boolean }) {
  return <div className={publicPage ? "public-loading" : "page-route-loading"} role="status"><span className="route-spinner"/><span>Opening your event studio…</span></div>;
}

function OrganizerRoutes() {
  return <OwnerGate><AppLayout><Suspense fallback={<RouteLoading/>}><Switch>
    <Route path="/studio" component={DashboardPage}/>
    <Route path="/events/new" component={EventsPage}/>
    <Route path="/events" component={EventsPage}/>
    <Route path="/events/:id" component={EventDetailsPage}/>
    <Route path="/registrations" component={RegistrationsPage}/>
    <Route path="/check-in" component={CheckInPage}/>
    <Route path="/analytics" component={AnalyticsPage}/>
    <Route path="/settings" component={SettingsPage}/>
    <Route component={NotFound}/>
  </Switch></Suspense></AppLayout></OwnerGate>;
}

function Router() {
  return <Switch>
    <Route path="/" component={() => <Suspense fallback={<RouteLoading publicPage/>}><PublicEventsPage/></Suspense>}/>
    <Route path="/event/:slug/register" component={() => <Suspense fallback={<RouteLoading publicPage/>}><PublicRegistrationPage/></Suspense>}/>
    <Route path="/event/:slug" component={() => <Suspense fallback={<RouteLoading publicPage/>}><PublicEventPage/></Suspense>}/>
    <Route path="/404" component={NotFound}/>
    <Route component={OrganizerRoutes}/>
  </Switch>;
}

function App() {
  const [reduceMotion, setReduceMotion] = useState(false);
  useEffect(() => {
    const syncPreference = () => {
      const enabled = localStorage.getItem("gather-reduce-motion") === "true";
      setReduceMotion(enabled);
      document.documentElement.dataset.reduceMotion = String(enabled);
    };
    syncPreference();
    window.addEventListener("gather-preferences-changed", syncPreference);
    return () => window.removeEventListener("gather-preferences-changed", syncPreference);
  }, []);
  return <ErrorBoundary><ThemeProvider defaultTheme="fieldnotes" switchable><TooltipProvider><MotionConfig reducedMotion={reduceMotion ? "always" : "user"}><Toaster richColors position="top-right"/><Router/></MotionConfig></TooltipProvider></ThemeProvider></ErrorBoundary>;
}

export default App;
