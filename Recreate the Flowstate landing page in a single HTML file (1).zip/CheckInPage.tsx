import { useMemo, useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Check, CheckCheck, ChevronDown, CircleDot, Clock3, Search, ScanLine, TicketCheck, Undo2, Users, X } from "lucide-react";
import { toast } from "sonner";
import { EmptyState, ErrorState, LoadingState, PageMotion, StatusBadge } from "@/components/StudioUI";
import { trpc } from "@/lib/trpc";
import { formatDate, initials } from "@/lib/format";
import type { RegistrationRow } from "@/types";

export default function CheckInPage() {
  const eventQuery = trpc.events.workspaceList.useQuery(undefined, { staleTime: 30_000 });
  const registrationQuery = trpc.events.registrationList.useQuery(undefined, { staleTime: 10_000, refetchInterval: 20_000 });
  const [eventId, setEventId] = useState(() => new URLSearchParams(window.location.search).get("event") || "");
  const [search, setSearch] = useState("");
  const utils = trpc.useUtils();
  const update = trpc.events.updateRegistration.useMutation({
    onSuccess: async (_result, variables) => {
      await Promise.all([utils.events.registrationList.invalidate(), utils.events.workspaceList.invalidate(), utils.events.overview.invalidate(), utils.events.analytics.invalidate()]);
      toast.success(variables.checkedIn ? "All checked in. Enjoy the moment." : "Check-in was undone.");
    },
    onError: (error) => toast.error(error.message),
  });
  const items = eventQuery.data ?? [];
  const selectable = items.filter((event) => event.status === "published" || event.registrationCount > 0);
  const selectedEvent = selectable.find((event) => String(event.id) === eventId) ?? selectable[0];
  const guests = useMemo(() => (registrationQuery.data ?? []).filter((row) => selectedEvent && row.eventId === selectedEvent.id && row.status !== "cancelled"), [registrationQuery.data, selectedEvent]);
  const filtered = guests.filter((row) => `${row.fullName} ${row.email} ${row.ticketCode}`.toLowerCase().includes(search.trim().toLowerCase()));
  const checkedIn = guests.filter((guest) => guest.checkedInAt).length;
  const progress = guests.length ? Math.round(checkedIn / guests.length * 100) : 0;

  if (eventQuery.isLoading || registrationQuery.isLoading) return <PageMotion><LoadingState label="Getting the door ready…"/></PageMotion>;
  if (eventQuery.error || registrationQuery.error) return <ErrorState message={eventQuery.error?.message || registrationQuery.error?.message || "Check-in could not be loaded."} onRetry={() => { eventQuery.refetch(); registrationQuery.refetch(); }}/>;

  return <PageMotion className="checkin-page">
    <div className="page-intro page-intro-compact"><div><p className="eyebrow"><span className="eyebrow-dot"/>A WARM WELCOME, EVERY TIME</p><h1>Guest check-in</h1><p className="page-intro-copy">A quick hello, a checked-in guest, and one less thing to worry about.</p></div><span className="checkin-live-pill"><i/>Live guest list</span></div>
    <section className="checkin-hero panel"><div className="checkin-hero-copy"><div className="checkin-kicker"><ScanLine size={15}/>DOOR DESK</div><h2>Make their first<br/><span>moment a welcome.</span></h2><p>Find a guest, confirm their ticket, and check them in. The list stays in sync with your registrations.</p><label className="field checkin-event-select"><span>Choose an experience</span><span className="select-shell"><select aria-label="Choose an event" value={selectedEvent?.id ?? ""} onChange={(e) => setEventId(e.target.value)}><option value="" disabled>Select an event…</option>{selectable.map((event) => <option value={event.id} key={event.id}>{event.title}</option>)}</select><ChevronDown size={15}/></span></label></div>
      <div className="checkin-ring-wrap"><div className="checkin-ring" style={{ "--progress": `${progress}%` } as React.CSSProperties}><div><CheckCheck size={22}/><strong>{checkedIn}<small>/{guests.length}</small></strong><span>ARRIVED</span></div></div><div className="checkin-ring-note"><span><i/>Checked in</span><b>{progress}%</b></div><div className="checkin-ring-label">of your confirmed guest list</div></div>
    </section>
    {selectedEvent ? <section className="panel checkin-list-panel">
      <div className="checkin-list-head"><div><div className="checkin-event-heading"><span className="checkin-event-icon"><TicketCheck size={17}/></span><div><h2>{selectedEvent.title}</h2><p><Clock3 size={13}/>{new Date(selectedEvent.startsAt).toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })} <i>·</i> {selectedEvent.venue || (selectedEvent.format === "online" ? "Online" : "Location to come")}</p></div></div></div><label className="directory-search checkin-search"><Search size={16}/><input aria-label="Search guest list" placeholder="Find a guest or ticket…" value={search} onChange={(e) => setSearch(e.target.value)}/>{search && <button aria-label="Clear search" onClick={() => setSearch("")}><X size={14}/></button>}</label></div>
      <div className="checkin-list-meta"><span><Users size={14}/><b>{guests.length}</b> expected</span><span><CheckCircleIcon/> <b>{checkedIn}</b> arrived</span><span className="checkin-list-spacer"/><span className="checkin-meta-hint">Tap a guest to check in or undo.</span></div>
      {filtered.length ? <div className="checkin-guest-list">{filtered.map((guest, index) => <CheckInGuest key={`${guest.itemType}-${guest.id}`} guest={guest} index={index} busy={update.isPending} onToggle={() => update.mutate({ id: guest.id, itemType: guest.itemType, checkedIn: !guest.checkedInAt })}/>)}</div> : guests.length ? <EmptyState icon={<Search size={20}/>} title="No name found" description="Try another guest name, email address, or ticket code." action={() => setSearch("")} actionLabel="Clear search"/> : <EmptyState icon={<TicketCheck size={21}/>} title="This list is ready for guests" description="Once people register, their names will appear here automatically."/>}
    </section> : <section className="panel"><EmptyState icon={<TicketCheck size={22}/>} title="No event is at the door yet" description="Publish an event and invite guests to register. Their list will be ready here." action={() => { window.location.href = "/events"; }} actionLabel="Go to events"/></section>}
    <div className="checkin-footnote"><span><CircleDot size={14}/>A good welcome is worth remembering.</span><Link href="/registrations"><Users size={14}/>View all registrations</Link></div>
  </PageMotion>;
}

function CheckCircleIcon() { return <Check size={14}/>; }

function CheckInGuest({ guest, index, busy, onToggle }: { guest: RegistrationRow; index: number; busy: boolean; onToggle: () => void }) {
  return <motion.div className={`checkin-guest ${guest.checkedInAt ? "is-checked-in" : ""}`} layout initial={{ opacity: 0, y: 7 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(index * 0.025, 0.2) }}>
    <span className={`guest-avatar guest-tone-${index % 5}`}>{initials(guest.fullName)}</span><span className="checkin-guest-details"><strong>{guest.fullName}</strong><small>{guest.email}</small></span><span className="ticket-code"><TicketCheck size={13}/>{guest.ticketCode}</span><span className="checkin-registered">Added {formatDate(guest.registeredAt, { month: "short", day: "numeric" })}</span><StatusBadge status={guest.status}/><button className={`checkin-toggle ${guest.checkedInAt ? "done" : ""}`} onClick={onToggle} disabled={busy || guest.status === "pending"} title={guest.checkedInAt ? "Undo check-in" : guest.status === "pending" ? "Confirm registration before check-in" : "Check in attendee"}>{guest.checkedInAt ? <><Check size={15}/><span>Arrived</span><Undo2 size={13} className="undo-icon"/></> : <><span>Check in</span><Check size={15}/></>}</button>
  </motion.div>;
}
