import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowDownToLine, Check, CheckCheck, ChevronDown, CircleDollarSign, Clipboard, Download, FilePenLine, Search, TicketCheck, Users, X } from "lucide-react";
import { toast } from "sonner";
import { Modal } from "@/components/Modal";
import { EmptyState, ErrorState, LoadingState, PageMotion, StatusBadge } from "@/components/StudioUI";
import { trpc } from "@/lib/trpc";
import { downloadCsv, formatDate, initials } from "@/lib/format";
import type { RegistrationRow, RegistrationStatus } from "@/types";

type StatusFilter = "all" | RegistrationStatus;

function answerEntries(raw?: string | null): Array<[string, string]> {
  if (!raw) return [];
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return [];
    return Object.entries(parsed).filter((entry): entry is [string, string] => typeof entry[1] === "string" && entry[1].trim().length > 0);
  } catch { return []; }
}

function formatAnswers(raw?: string | null) { return answerEntries(raw).map(([question, answer]) => `${question}: ${answer}`).join(" | "); }

export default function RegistrationsPage() {
  const query = trpc.events.registrationList.useQuery(undefined, { staleTime: 20_000 });
  const eventQuery = trpc.events.workspaceList.useQuery(undefined, { staleTime: 45_000 });
  const utils = trpc.useUtils();
  const [search, setSearch] = useState(() => new URLSearchParams(window.location.search).get("search") || "");
  const [status, setStatus] = useState<StatusFilter>(() => {
    const requested = new URLSearchParams(window.location.search).get("status");
    return requested === "confirmed" || requested === "pending" || requested === "cancelled" ? requested : "all";
  });
  const [eventId, setEventId] = useState(() => new URLSearchParams(window.location.search).get("event") || "all");
  const [selected, setSelected] = useState<string[]>([]);
  const [notesTarget, setNotesTarget] = useState<RegistrationRow | null>(null);
  const [notesDraft, setNotesDraft] = useState("");
  const [answersTarget, setAnswersTarget] = useState<RegistrationRow | null>(null);
  const rows = query.data ?? [];
  const filtered = useMemo(() => rows.filter((item) => {
    const text = `${item.fullName} ${item.email} ${item.eventTitle} ${item.ticketCode} ${item.phone}`.toLowerCase();
    return (status === "all" || item.status === status) && (eventId === "all" || item.eventId === Number(eventId)) && text.includes(search.trim().toLowerCase());
  }), [eventId, rows, search, status]);
  const update = trpc.events.updateRegistration.useMutation({
    onSuccess: async (_value, variables) => {
      await Promise.all([utils.events.registrationList.invalidate(), utils.events.overview.invalidate(), utils.events.workspaceList.invalidate(), utils.events.analytics.invalidate()]);
      if (variables.checkedIn !== undefined) toast.success(variables.checkedIn ? "Guest checked in." : "Check-in removed.");
      else if (variables.status) toast.success(`Registration ${variables.status}.`);
      else if (variables.paymentStatus) toast.success("Payment status saved.");
    },
    onError: (error) => toast.error(error.message),
  });
  const bulkUpdate = trpc.events.bulkUpdate.useMutation({
    onSuccess: async (result) => { setSelected([]); await Promise.all([utils.events.registrationList.invalidate(), utils.events.overview.invalidate(), utils.events.analytics.invalidate()]); toast.success(`${result.updated} registration${result.updated === 1 ? "" : "s"} updated.`); },
    onError: (error) => toast.error(error.message),
  });

  useEffect(() => { setSelected((current) => current.filter((key) => filtered.some((row) => `${row.itemType}:${row.id}` === key))); }, [filtered]);
  const keyFor = (row: RegistrationRow) => `${row.itemType}:${row.id}`;
  const toggleOne = (row: RegistrationRow) => setSelected((current) => current.includes(keyFor(row)) ? current.filter((key) => key !== keyFor(row)) : [...current, keyFor(row)]);
  const allSelected = filtered.length > 0 && filtered.every((row) => selected.includes(keyFor(row)));
  const toggleAll = () => setSelected(allSelected ? [] : filtered.map(keyFor));
  const selectedItems = rows.filter((row) => selected.includes(keyFor(row))).map((row) => ({ id: row.id, itemType: row.itemType }));

  const exportRows = () => {
    downloadCsv("gather-registrations.csv", filtered.map((row) => ({
      attendee: row.fullName,
      email: row.email,
      phone: row.phone,
      offering: row.eventTitle,
      type: row.itemType,
      registeredAt: row.registeredAt.toISOString(),
      status: row.status,
      paymentStatus: row.paymentStatus,
      ticketCode: row.ticketCode,
      checkedInAt: row.checkedInAt?.toISOString() || "",
      comments: row.comments || "",
      customAnswers: formatAnswers(row.customAnswers),
      notes: row.notes || "",
    })));
    if (filtered.length) toast.success(`${filtered.length} attendee records exported.`);
  };
  const openNotes = (row: RegistrationRow) => { setNotesTarget(row); setNotesDraft(row.notes || ""); };
  const saveNotes = () => { if (!notesTarget) return; update.mutate({ id: notesTarget.id, itemType: notesTarget.itemType, notes: notesDraft }); setNotesTarget(null); };

  if (query.isLoading || eventQuery.isLoading) return <PageMotion><LoadingState label="Gathering your guest list…"/></PageMotion>;
  if (query.error || eventQuery.error) return <ErrorState message={query.error?.message || eventQuery.error?.message || "Your registrations could not be loaded."} onRetry={() => { query.refetch(); eventQuery.refetch(); }}/>;

  const statuses: Array<{ key: StatusFilter; label: string }> = [{ key: "all", label: "Everyone" }, { key: "confirmed", label: "Confirmed" }, { key: "pending", label: "Pending" }, { key: "cancelled", label: "Cancelled" }];
  const countStatus = (key: StatusFilter) => key === "all" ? rows.length : rows.filter((row) => row.status === key).length;
  return <PageMotion className="registrations-page">
    <div className="page-intro page-intro-compact"><div><p className="eyebrow"><span className="eyebrow-dot"/>THE PEOPLE MAKING IT HAPPEN</p><h1>Registrations</h1><p className="page-intro-copy">One thoughtful guest list. Every attendee, all in one place.</p></div><button className="button button-secondary" onClick={exportRows} disabled={!filtered.length}><ArrowDownToLine size={16}/>Export guest list</button></div>
    <div className="registration-summary-row"><div className="registration-summary-item"><span className="summary-dot confirmed-dot"/><strong>{rows.filter((row) => row.status === "confirmed").length}</strong><small>confirmed</small></div><div className="registration-summary-item"><span className="summary-dot pending-dot"/><strong>{rows.filter((row) => row.status === "pending").length}</strong><small>pending</small></div><div className="registration-summary-item"><span className="summary-dot checkin-dot"/><strong>{rows.filter((row) => row.status === "confirmed" && row.checkedInAt).length}</strong><small>checked in</small></div><span className="summary-side-note"><Users size={14}/>{rows.length} guest record{rows.length === 1 ? "" : "s"} across your workspace</span></div>
    <section className="panel registrations-panel">
      <div className="directory-tabs registration-tabs" role="tablist" aria-label="Filter registrations">{statuses.map((item) => <button key={item.key} role="tab" aria-selected={status === item.key} className={status === item.key ? "active" : ""} onClick={() => setStatus(item.key)}>{item.label}<span>{countStatus(item.key)}</span></button>)}</div>
      <div className="registration-toolbar"><label className="directory-search"><Search size={17}/><input placeholder="Search guests, events, or ticket codes…" aria-label="Search registrations" value={search} onChange={(e) => setSearch(e.target.value)}/>{search && <button onClick={() => setSearch("")} aria-label="Clear search"><X size={14}/></button>}</label><label className="filter-control"><span>All experiences</span><select aria-label="Filter by event" value={eventId} onChange={(e) => setEventId(e.target.value)}><option value="all">All experiences</option>{eventQuery.data?.map((event) => <option value={event.id} key={event.id}>{event.title}</option>)}</select><ChevronDown size={13}/></label></div>
      {selected.length > 0 && <motion.div className="bulk-toolbar" initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }}><span><CheckCheck size={15}/><b>{selected.length}</b> selected</span><button onClick={() => bulkUpdate.mutate({ items: selectedItems, status: "confirmed" })}><Check size={14}/>Confirm</button><button onClick={() => bulkUpdate.mutate({ items: selectedItems, status: "cancelled" })} className="bulk-cancel">Cancel registrations</button><button className="bulk-clear" onClick={() => setSelected([])}>Clear</button></motion.div>}
      {filtered.length ? <div className="registrations-table-wrap"><table className="registrations-table"><thead><tr><th className="select-column"><input type="checkbox" checked={allSelected} onChange={toggleAll} aria-label="Select all registrations"/></th><th>ATTENDEE</th><th>EXPERIENCE</th><th>REGISTERED</th><th>STATUS</th><th>PAYMENT</th><th>CHECK-IN</th><th><span className="sr-only">Actions</span></th></tr></thead><tbody>{filtered.map((row, index) => <motion.tr key={keyFor(row)} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: Math.min(index * .025, .2) }}>
        <td className="select-column"><input type="checkbox" checked={selected.includes(keyFor(row))} onChange={() => toggleOne(row)} aria-label={`Select ${row.fullName}`}/></td>
        <td><div className="table-attendee"><span className={`guest-avatar guest-tone-${index % 5}`}>{initials(row.fullName)}</span><span><strong>{row.fullName}</strong><small>{row.email}{row.phone ? ` · ${row.phone}` : ""}</small></span></div></td>
        <td><Link className="registration-event-link" href={`/events/${row.eventId}`}>{row.eventTitle}<span>{row.itemType === "workshop" ? "Workshop" : "Event"} · {row.ticketCode}</span></Link></td>
        <td className="registration-date-cell">{formatDate(row.registeredAt, { month: "short", day: "numeric", year: "numeric" })}<span>{row.registeredAt.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}</span></td>
        <td><StatusBadge status={row.status}/></td>
        <td><button className={`payment-pill payment-${row.paymentStatus}`} title="Change payment status" onClick={() => {
          const options = ["waived", "unpaid", "paid", "refunded"] as const; const next = options[(options.indexOf(row.paymentStatus) + 1) % options.length]; update.mutate({ id: row.id, itemType: row.itemType, paymentStatus: next });
        }}><CircleDollarSign size={13}/>{row.paymentStatus}</button></td>
        <td>{row.checkedInAt && row.status === "confirmed" ? <span className="checkin-done"><Check size={13}/>Arrived</span> : row.status === "confirmed" ? <button className="text-button checkin-action" onClick={() => update.mutate({ id: row.id, itemType: row.itemType, checkedIn: true })}><TicketCheck size={14}/>Check in</button> : <span className="checkin-waiting">{row.status === "cancelled" ? "Cancelled" : "Confirm first"}</span>}</td>
        <td><div className="table-row-actions">{answerEntries(row.customAnswers).length > 0 && <button className="button-icon tiny-icon" aria-label={`View custom answers for ${row.fullName}`} title="View registration answers" onClick={() => setAnswersTarget(row)}><Clipboard size={15}/></button>}<button className="button-icon tiny-icon" aria-label={`Edit notes for ${row.fullName}`} onClick={() => openNotes(row)}><FilePenLine size={15}/></button>{row.status !== "cancelled" && <button className="button-icon tiny-icon" aria-label={`Cancel ${row.fullName}'s registration`} onClick={() => update.mutate({ id: row.id, itemType: row.itemType, status: "cancelled" })}><X size={15}/></button>}</div></td>
      </motion.tr>)}</tbody></table></div> : rows.length ? <EmptyState icon={<Search size={21}/>} title="No guests on this list" description="Try broadening your search or changing the event and status filters." action={() => { setSearch(""); setStatus("all"); setEventId("all"); }} actionLabel="Clear filters"/> : <EmptyState icon={<Users size={21}/>} title="A place for every guest" description="Share a public event link to welcome your first attendee. Guest details stay private to your workspace." action={() => { window.location.href = "/events"; }} actionLabel="Explore events"/>}
      <div className="table-footer"><span>Showing <b>{filtered.length}</b> of <b>{rows.length}</b> registrations</span><span><Download size={13}/>CSV export includes current filters</span></div>
    </section>
    <Modal open={!!notesTarget} onClose={() => setNotesTarget(null)} title="A note for your team" description={notesTarget ? `${notesTarget.fullName} · ${notesTarget.eventTitle}` : ""}>
      <div className="notes-editor"><label className="field"><span>Organizer notes</span><textarea rows={5} autoFocus value={notesDraft} onChange={(e) => setNotesDraft(e.target.value)} placeholder="Anything your team should remember about this guest?"/></label><div className="modal-actions"><button className="button button-quiet" onClick={() => setNotesTarget(null)}>Cancel</button><button className="button button-primary" onClick={saveNotes}><Check size={15}/>Save note</button></div></div>
    </Modal>
    <Modal open={!!answersTarget} onClose={() => setAnswersTarget(null)} title="Guest responses" description={answersTarget ? `${answersTarget.fullName} · ${answersTarget.eventTitle}` : ""}>
      <div className="answer-list">{answersTarget && answerEntries(answersTarget.customAnswers).map(([question, answer]) => <article className="answer-entry" key={question}><strong>{question}</strong><p>{answer}</p></article>)}<div className="modal-actions"><button className="button button-primary" onClick={() => setAnswersTarget(null)}>Done</button></div></div>
    </Modal>
  </PageMotion>;
}
