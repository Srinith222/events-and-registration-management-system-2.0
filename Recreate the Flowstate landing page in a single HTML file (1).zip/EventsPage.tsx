import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { AnimatePresence, motion } from "framer-motion";
import { CalendarDays, ChevronDown, LayoutGrid, List, Plus, Search, SlidersHorizontal, Sparkles, X } from "lucide-react";
import { toast } from "sonner";
import { EventCard } from "@/components/EventCard";
import { EventEditorDialog } from "@/components/EventEditorDialog";
import { EmptyState, ErrorState, LoadingState, PageMotion } from "@/components/StudioUI";
import { trpc } from "@/lib/trpc";
import type { WorkspaceEvent } from "@/types";

type StatusFilter = "all" | "published" | "draft" | "archived";
type TypeFilter = "all" | "event" | "workshop";

export default function EventsPage() {
  const [location, navigate] = useLocation();
  const [search, setSearch] = useState(() => new URLSearchParams(window.location.search).get("q") || "");
  const [status, setStatus] = useState<StatusFilter>("all");
  const [type, setType] = useState<TypeFilter>("all");
  const [sort, setSort] = useState("date");
  const [view, setView] = useState<"card" | "row">("card");
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<WorkspaceEvent | null>(null);
  const query = trpc.events.workspaceList.useQuery(undefined, { staleTime: 20_000 });
  const items = query.data ?? [];
  const visible = useMemo(() => items.filter((item) => {
    const text = `${item.title} ${item.description} ${item.venue} ${item.category}`.toLowerCase();
    return (status === "all" || item.status === status) && (type === "all" || item.type === type) && text.includes(search.trim().toLowerCase());
  }).sort((a, b) => sort === "title" ? a.title.localeCompare(b.title) : sort === "registrations" ? b.registrationCount - a.registrationCount : sort === "created" ? b.createdAt.getTime() - a.createdAt.getTime() : a.startsAt.getTime() - b.startsAt.getTime()), [items, search, sort, status, type]);

  useEffect(() => {
    if (location === "/events/new") { setEditing(null); setEditorOpen(true); }
  }, [location]);

  const openCreate = () => { setEditing(null); setEditorOpen(true); };
  const closeEditor = () => { setEditorOpen(false); if (location === "/events/new") navigate("/events"); };
  const openEdit = (item: WorkspaceEvent) => { setEditing(item); setEditorOpen(true); };
  const statusOptions: Array<{ key: StatusFilter; label: string }> = [
    { key: "all", label: "Everything" }, { key: "published", label: "Published" }, { key: "draft", label: "Drafts" }, { key: "archived", label: "Archived" },
  ];
  const countFor = (key: StatusFilter) => key === "all" ? items.length : items.filter((item) => item.status === key).length;

  if (query.isLoading) return <PageMotion><LoadingState label="Laying out your event board…" /></PageMotion>;
  if (query.error) return <ErrorState message={query.error.message} onRetry={() => query.refetch()} />;

  return <PageMotion className="events-page">
    <div className="page-intro page-intro-compact"><div><p className="eyebrow"><span className="eyebrow-dot"/>MAKE ROOM FOR GOOD THINGS</p><h1>Events & workshops</h1><p className="page-intro-copy">All the little details behind a memorable gathering.</p></div><button className="button button-primary" onClick={openCreate}><Plus size={18}/>Create event</button></div>
    <div className="event-overview-strip"><div><span className="overview-strip-icon"><CalendarDays size={16}/></span><span><b>{items.length}</b> total experiences</span></div><i/><div><span className="strip-green-dot"/><span><b>{countFor("published")}</b> live for registration</span></div><span className="strip-side-note"><Sparkles size={14}/> A well-planned moment goes a long way.</span></div>
    <section className="panel directory-panel">
      <div className="directory-tabs" role="tablist" aria-label="Filter by status">{statusOptions.map((option) => <button key={option.key} role="tab" aria-selected={status === option.key} className={status === option.key ? "active" : ""} onClick={() => setStatus(option.key)}>{option.label}<span>{countFor(option.key)}</span></button>)}</div>
      <div className="directory-toolbar">
        <label className="directory-search"><Search size={17}/><input aria-label="Search events" placeholder="Find an event, place, or category…" value={search} onChange={(e) => setSearch(e.target.value)}/>{search && <button onClick={() => setSearch("")} aria-label="Clear search"><X size={14}/></button>}</label>
        <div className="directory-controls"><label className="filter-control"><SlidersHorizontal size={14}/><select aria-label="Offering type" value={type} onChange={(e) => setType(e.target.value as TypeFilter)}><option value="all">All types</option><option value="event">Events</option><option value="workshop">Workshops</option></select><ChevronDown size={13}/></label><label className="sort-control"><span>Sort by</span><select aria-label="Sort events" value={sort} onChange={(e) => setSort(e.target.value)}><option value="date">Upcoming</option><option value="created">Recently added</option><option value="registrations">Most registrations</option><option value="title">Name A–Z</option></select><ChevronDown size={13}/></label><div className="view-toggle" role="group" aria-label="Directory view"><button className={view === "card" ? "selected" : ""} aria-label="Card view" onClick={() => setView("card")}><LayoutGrid size={16}/></button><button className={view === "row" ? "selected" : ""} aria-label="Table view" onClick={() => setView("row")}><List size={17}/></button></div></div>
      </div>
      <AnimatePresence mode="wait">
        {visible.length ? view === "card" ? <motion.div key="cards" className="event-card-grid" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }}>{visible.map((event) => <EventCard key={event.id} event={event} onEdit={openEdit}/>)}</motion.div> : <motion.div key="rows" className="event-table" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }}><div className="event-table-head"><span>EXPERIENCE</span><span>DATE & TIME</span><span>GUESTS</span><span>STATUS</span><span/></div>{visible.map((event) => <EventCard key={event.id} event={event} onEdit={openEdit} view="row" />)}</motion.div> : items.length ? <EmptyState icon={<Search size={21}/>} title="Nothing at this angle" description="Try another phrase or loosen a filter to find your event." action={() => { setSearch(""); setStatus("all"); setType("all"); }} actionLabel="Clear filters"/> : <EmptyState icon={<CalendarDays size={21}/>} title="Your next great gathering starts here" description="Create an event or a workshop, set a few details, and invite your people." action={openCreate} actionLabel="Create your first event"/>}
      </AnimatePresence>
    </section>
    <EventEditorDialog open={editorOpen} onClose={closeEditor} event={editing}/>
  </PageMotion>;
}
