import { useMemo, useState } from "react";
import { Link } from "wouter";
import { ArrowDown, ArrowRight, CalendarDays, Clock3, MapPin, Search, Ticket, Users } from "lucide-react";
import { GalleryHeading } from "@designcodeio/threeui";
import { EVENT_OWNER_EMAIL } from "@shared/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { ErrorState, LoadingState, PageMotion } from "@/components/StudioUI";
import { trpc } from "@/lib/trpc";
import { CompanyEventsSection } from "@/components/CompanyEventsSection";
import { mncEvents } from "@/data/mncEvents";

type KindFilter = "all" | "event" | "workshop";

const dateParts = (value: Date | string) => {
  const date = new Date(value);
  return {
    month: new Intl.DateTimeFormat("en", { month: "short" }).format(date).toUpperCase(),
    day: new Intl.DateTimeFormat("en", { day: "2-digit" }).format(date),
    weekday: new Intl.DateTimeFormat("en", { weekday: "long" }).format(date),
    full: new Intl.DateTimeFormat("en", { month: "long", day: "numeric", year: "numeric" }).format(date),
    time: new Intl.DateTimeFormat("en", { hour: "numeric", minute: "2-digit" }).format(date),
  };
};

const formatRange = (start: Date | string, end: Date | string) => {
  const startDate = new Date(start);
  const endDate = new Date(end);
  const a = dateParts(startDate);
  if (startDate.toDateString() === endDate.toDateString()) return `${a.full} · ${a.time}`;
  return `${a.full} – ${dateParts(endDate).full}`;
};

export default function PublicEventsPage() {
  const [filter, setFilter] = useState<KindFilter>("all");
  const [query, setQuery] = useState("");
  const { user } = useAuth();
  const { data: offerings = [], isLoading, error, refetch } = trpc.events.listPublished.useQuery(undefined, { staleTime: 30_000 });
  const ownerSignedIn = user?.email?.trim().toLowerCase() === EVENT_OWNER_EMAIL.toLowerCase();
  const visible = useMemo(() => {
    const term = query.trim().toLowerCase();
    return offerings.filter((item) => {
      const kindMatches = filter === "all" || item.type === filter;
      const termMatches = !term || `${item.title} ${item.category} ${item.description} ${item.venue}`.toLowerCase().includes(term);
      return kindMatches && termMatches;
    });
  }, [filter, offerings, query]);
  const featured = visible[0];

  return <PageMotion className="public-calendar-page">
    <header className="public-calendar-nav">
      <Link href="/" className="public-calendar-brand" aria-label="Gather public event calendar">
        <span className="public-brand-glyph">g<span>.</span></span>
        <span className="public-brand-name">gather<small>THE EVENT CALENDAR</small></span>
      </Link>
      <div className="public-nav-center"><span>UPCOMING</span><span className="nav-divider"/><span>EVENTS & WORKSHOPS</span></div>
      <Link href={ownerSignedIn ? "/studio" : "/studio"} className="public-owner-link">{ownerSignedIn ? "Owner studio" : "Owner sign in"}<ArrowRight size={15}/></Link>
    </header>

    <main className="public-calendar-main">
      <section className="public-calendar-hero">
        <div className="calendar-hero-copy">
          <p className="print-kicker"><span className="kicker-rule"/>A GOOD REASON TO GET TOGETHER</p>
          <h1>Make room<br/>for <em>something</em><br/>good.</h1>
          <p className="calendar-hero-intro">Thoughtful gatherings, useful workshops, and little plans worth putting on the calendar.</p>
          <a href="#calendar-list" className="text-link calendar-scroll-link">Find your next date <ArrowDown size={16}/></a>
        </div>
        <div className="calendar-hero-gallery">
          <GalleryHeading
            variant="rising-diagonal"
            mode="dark"
            font="sans"
            weight="400"
            headlineSize={1.15}
            hue={0}
            saturation={1.00}
            brightness={1.00}
          />
        </div>
      </section>

      <section className="calendar-list-section" id="calendar-list">
        <div className="calendar-list-heading">
          <div><p className="print-kicker"><span className="kicker-rule"/>THE OPEN INVITATION</p><h2>On the calendar<span className="heading-period">.</span></h2><p className="calendar-list-subtitle">Pick the gathering that feels like your kind of day.</p></div>
          <div className="calendar-list-tools">
            <label className="public-event-search"><Search size={16}/><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search the calendar" aria-label="Search upcoming events"/><kbd>/</kbd></label>
            <div className="calendar-kind-filter" role="group" aria-label="Filter calendar by type">
              {(["all", "event", "workshop"] as const).map((value) => <button key={value} className={filter === value ? "selected" : ""} aria-pressed={filter === value} onClick={() => setFilter(value)}>{value === "all" ? "Everything" : value === "event" ? "Events" : "Workshops"}</button>)}
            </div>
          </div>
        </div>

        {isLoading ? <div className="public-calendar-loading"><LoadingState label="Gathering the upcoming dates…"/></div> : error ? <div className="public-calendar-error"><ErrorState message="We couldn't load the event calendar." onRetry={() => refetch()}/></div> : !visible.length ? <div className="public-calendar-empty">
          <span className="empty-calendar-mark"><CalendarDays size={23}/></span>
          <div><span className="empty-overline">NO DATES FOUND</span><h3>{offerings.length ? "Nothing by that name just yet." : "The next good thing is being planned."}</h3><p>{offerings.length ? "Try another search or switch the calendar filter." : "Check back soon for new gatherings. You can register from this page as soon as an invitation opens."}</p></div>
          {ownerSignedIn && !offerings.length && <Link href="/events/new" className="button button-primary">Plan a gathering <ArrowRight size={16}/></Link>}
          {offerings.length > 0 && <button className="text-link" onClick={() => { setQuery(""); setFilter("all"); }}>Clear filters <ArrowRight size={15}/></button>}
        </div> : <>
          {featured && <Link href={`/event/${featured.slug}`} className="calendar-featured" aria-label={`View invitation for ${featured.title}`}>
            <div className={`calendar-featured-art tone-${featured.id % 4}${featured.coverUrl ? " has-image" : ""}`}>
              {featured.coverUrl && <img src={featured.coverUrl} alt="" loading="lazy"/>}
              <span className="featured-art-caption">THE NEXT DATE</span>
              <span className="featured-art-index">{String(featured.id).padStart(2, "0")}</span>
              <div className="featured-date-stamp"><span>{dateParts(featured.startsAt).month}</span><strong>{dateParts(featured.startsAt).day}</strong></div>
              <span className="featured-art-bottom">GATHER / OPEN INVITATION</span>
            </div>
            <div className="calendar-featured-copy">
              <div className="featured-copy-top"><span className="event-kind-label">{featured.type === "workshop" ? "WORKSHOP" : featured.category.toUpperCase()}</span><span className={featured.registrationOpen ? "availability-label is-open" : "availability-label"}>{featured.registrationOpen ? "PLACES OPEN" : "REGISTRATION CLOSED"}</span></div>
              <h3>{featured.title}</h3>
              <p className="featured-description">{featured.description || "A good date, a place to meet, and a little something to look forward to."}</p>
              <div className="featured-event-facts"><span><CalendarDays size={15}/>{formatRange(featured.startsAt, featured.endsAt)}</span><span><MapPin size={15}/>{featured.venue || (featured.format === "online" ? "Online" : "Venue details on invitation")}</span><span><Users size={15}/>{featured.registrationOpen ? `${featured.remainingSeats} places available` : "See invitation for details"}</span></div>
              <span className="featured-invitation-link">Read the invitation <ArrowRight size={16}/></span>
            </div>
          </Link>}

          <div className="calendar-results-heading"><span>{filter === "all" ? "COMING UP" : filter === "event" ? "UPCOMING EVENTS" : "UPCOMING WORKSHOPS"}</span><span>{visible.length.toString().padStart(2, "0")} {visible.length === 1 ? "DATE" : "DATES"}</span></div>
          <div className="public-event-grid">{visible.slice(1).map((item) => {
            const date = dateParts(item.startsAt);
            return <article className="public-event-card" key={item.id}>
              <Link href={`/event/${item.slug}`} className={`public-event-card-art tone-${item.id % 4}${item.coverUrl ? " has-image" : ""}`} aria-label={`View ${item.title}`}>
                {item.coverUrl && <img src={item.coverUrl} alt="" loading="lazy"/>}
                <span className="event-date-block"><small>{date.month}</small><strong>{date.day}</strong></span>
                <span className="public-card-index">G / {String(item.id).padStart(2, "0")}</span>
                <span className="public-card-art-footer">{item.type === "workshop" ? "WORKSHOP" : item.category.toUpperCase()}</span>
              </Link>
              <div className="public-event-card-copy"><div className="public-event-meta"><span>{item.type === "workshop" ? "Workshop" : item.category}</span><span className={item.registrationOpen ? "availability-dot open" : "availability-dot"}>{item.registrationOpen ? "Open" : "Closed"}</span></div>
                <h3><Link href={`/event/${item.slug}`}>{item.title}</Link></h3>
                <p className="public-card-date"><Clock3 size={14}/>{formatRange(item.startsAt, item.endsAt)}</p>
                <p className="public-card-venue"><MapPin size={14}/>{item.venue || (item.format === "online" ? "Online" : "Details on invitation")}</p>
                <div className="public-card-bottom"><span><Users size={14}/>{item.registrationOpen ? `${item.remainingSeats} places left` : "Invitation details"}</span><Link href={`/event/${item.slug}`} aria-label={`Open invitation for ${item.title}`}><ArrowRight size={17}/></Link></div>
              </div>
            </article>;
          })}</div>
        </>}
      </section>

      <CompanyEventsSection events={mncEvents} />
      <section className="visitor-note"><span className="visitor-note-icon"><Ticket size={18}/></span><p><strong>Just here to join in?</strong> No account or sign-in is needed. Open an invitation and save your place.</p><span className="visitor-note-end">See you there.</span></section>
    </main>
    <footer className="public-calendar-footer"><span className="footer-mark">g.</span><span>Gather — an open calendar for good company.</span><Link href={ownerSignedIn ? "/studio" : "/studio"}>{ownerSignedIn ? "Owner studio" : "Host an event"}<ArrowRight size={14}/></Link></footer>
  </PageMotion>;
}
