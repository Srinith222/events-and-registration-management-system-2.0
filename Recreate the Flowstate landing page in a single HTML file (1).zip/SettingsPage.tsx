import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Check, CircleHelp, Cog, ExternalLink, Globe2, LockKeyhole, Mail, Moon, Settings2, Sparkles, UserRound } from "lucide-react";
import { toast } from "sonner";
import { EVENT_OWNER_EMAIL } from "@shared/const";
import { PageMotion } from "@/components/StudioUI";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

export default function SettingsPage() {
  const { user, logout } = useAuth();
  const [workspace, setWorkspace] = useState(user?.name ? `${user.name.split(" ")[0]}'s studio` : "Gather studio");
  const [reduceMotion, setReduceMotion] = useState(false);
  const [saved, setSaved] = useState(false);
  const mailStatus = trpc.events.mailStatus.useQuery(undefined, { staleTime: 30_000 });
  useEffect(() => {
    try {
      setWorkspace(localStorage.getItem("gather-workspace-label") || (user?.name ? `${user.name.split(" ")[0]}'s studio` : "Gather studio"));
      setReduceMotion(localStorage.getItem("gather-reduce-motion") === "true");
    } catch { /* Storage can be unavailable in private browser contexts. */ }
  }, [user?.name]);
  useEffect(() => { document.documentElement.dataset.reduceMotion = String(reduceMotion); }, [reduceMotion]);
  const save = () => {
    try { localStorage.setItem("gather-workspace-label", workspace.trim() || "Gather studio"); localStorage.setItem("gather-reduce-motion", String(reduceMotion)); } catch { /* Keep the current session responsive even if storage is blocked. */ }
    window.dispatchEvent(new Event("gather-preferences-changed"));
    setSaved(true); toast.success("Your preferences are saved on this device."); window.setTimeout(() => setSaved(false), 1800);
  };

  return <PageMotion className="settings-page">
    <div className="page-intro page-intro-compact"><div><p className="eyebrow"><span className="eyebrow-dot"/>MAKE YOUR STUDIO FEEL LIKE YOURS</p><h1>Settings</h1><p className="page-intro-copy">A few details about your workspace and how it should feel.</p></div></div>
    <div className="settings-layout"><aside className="settings-nav panel"><div className="settings-nav-title">YOUR WORKSPACE</div><a href="#profile" className="settings-nav-item active"><UserRound size={16}/>Profile</a><a href="#preferences" className="settings-nav-item"><Settings2 size={16}/>Preferences</a><a href="#privacy" className="settings-nav-item"><LockKeyhole size={16}/>Privacy & data</a><div className="settings-nav-divider"/><a href="mailto:support@gather.example" className="settings-nav-item"><CircleHelp size={16}/>Help & support<ExternalLink size={13}/></a></aside>
      <div className="settings-content"><section id="profile" className="panel settings-card"><div className="settings-card-heading"><span className="settings-card-icon blue"><Globe2 size={18}/></span><div><h2>Workspace profile</h2><p>How your organizer studio appears in the sidebar.</p></div></div><label className="field settings-field"><span>Workspace name</span><input value={workspace} maxLength={60} onChange={(e) => setWorkspace(e.target.value)} placeholder="Your event studio"/><small>Saved in this browser; your events and attendee data remain in MySQL.</small></label><div className="profile-readonly"><span className="settings-avatar">{(user?.name || "G").split(" ").slice(0,2).map((part) => part[0]).join("").toUpperCase()}</span><div><strong>{user?.name || "Organizer"}</strong><span>{user?.email || "Signed in with Manus"}</span></div><span className="verified-session"><Check size={12}/>Signed in</span></div></section>
      <section id="preferences" className="panel settings-card"><div className="settings-card-heading"><span className="settings-card-icon violet"><Sparkles size={18}/></span><div><h2>Studio preferences</h2><p>Small things that make a long planning day easier.</p></div></div><div className="preference-row"><span className="preference-icon"><Moon size={16}/></span><div><strong>Reduce motion</strong><p>Limit larger movement and transition effects in this browser.</p></div><button role="switch" aria-checked={reduceMotion} aria-label="Reduce motion" className={`toggle-switch ${reduceMotion ? "on" : ""}`} onClick={() => setReduceMotion(!reduceMotion)}><i/></button></div><div className="preference-row mail-automation-row"><span className="preference-icon"><Mail size={16}/></span><div><strong>Registration confirmations</strong><p>{mailStatus.data?.configured ? `Gmail credentials are saved. Confirmed registrations will trigger an email attempt from ${EVENT_OWNER_EMAIL}.` : "Gmail is not configured yet. Registrations will still save, but no confirmation email will be sent."}</p><small>{mailStatus.data?.configured ? "The AI adds one generic greeting sentence; no attendee details are shared with it. A delivery failure will not undo registration." : "Use the secure connection prompt to add a Gmail app password. Never paste it into chat."}</small></div><span className={`mail-status-chip ${mailStatus.data?.configured ? "connected" : ""}`}>{mailStatus.isLoading ? "Checking" : mailStatus.error ? "Unavailable" : mailStatus.data?.configured ? "Credentials ready" : "Setup needed"}</span></div></section>
      <section id="privacy" className="panel settings-card"><div className="settings-card-heading"><span className="settings-card-icon mint"><LockKeyhole size={18}/></span><div><h2>Privacy & data</h2><p>Attendee details are scoped to your signed-in organizer workspace.</p></div></div><div className="privacy-note"><span><LockKeyhole size={16}/></span><p><strong>Your guest list stays yours.</strong><br/>Organizer pages require sign-in. Public event pages show event details and registration availability, never other attendees' personal information.</p></div><div className="privacy-actions"><span><Cog size={15}/>Data is stored in the project's MySQL database.</span><button className="text-button" onClick={async () => { await logout(); window.location.reload(); }}>Sign out of Gather</button></div></section>
      <div className="settings-save-row"><span>Preferences are stored locally on this device.</span><button className="button button-primary" onClick={save}>{saved ? <Check size={16}/> : <Settings2 size={16}/>} {saved ? "Saved" : "Save preferences"}</button></div></div></div>
  </PageMotion>;
}
