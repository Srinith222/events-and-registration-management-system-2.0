import { Link, useLocation, useParams } from "wouter";
import { ArrowLeft, ArrowRight, CalendarDays, CalendarRange, Check, Clock3, MapPin, Share2, Sparkles, Users } from "lucide-react";
import { toast } from "sonner";
import { ErrorState, LoadingState, PageMotion } from "@/components/StudioUI";
import { trpc } from "@/lib/trpc";
import { formatDateRange, formatMoney } from "@/lib/format";

export default function PublicEventPage() {
  const { slug = "" } = useParams<{ slug: string }>();
  const [, navigate] = useLocation();
  const query = trpc.events.getPublicBySlug.useQuery({ slug }, { retry: false });
  const result = query.data;
  const share = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try { await navigator.share({ title: result?.event.title, text: "Come be part of this gathering.", url }); } catch { /* User dismissed the native share sheet. */ }
    } else {
      await navigator.clipboard.writeText(url); toast.success("Event link copied.");
    }
  };
  if (query.isLoading) return <div className="public-loading"><LoadingState label="Opening the invitation…"/></div>;
  if (query.error || !result) return <div className="public-not-found"><Link className="public-back" href="/"><ArrowLeft size={15}/>Gather</Link><ErrorState message={query.error?.message || "This invitation isn't available."} onRetry={() => query.refetch()}/></div>;
  const { event, workshopDetails } = result;
  const dateLine = formatDateRange(event.startsAt, event.endsAt);
  const coverTone = ["blue", "violet", "mint", "peach"][event.id % 4];

  return <PageMotion className="public-page">
    <header className="public-topbar"><Link href="/" className="public-brand"><span className="public-brand-icon"><CalendarDays size={18}/></span><span>gather<span>.</span></span></Link><span className="public-header-note"><Sparkles size={13}/> Good things happen together.</span><button className="button button-quiet public-share" onClick={share}><Share2 size={15}/>Share</button></header>
    <main className="public-event-main">
      <div className={`public-event-art tone-${coverTone}${event.coverUrl ? " has-cover" : ""}`}>{event.coverUrl && <img className="cover-image" src={event.coverUrl} loading="lazy" alt=""/>}<span className="art-sun"/><span className="art-line art-line-one"/><span className="art-line art-line-two"/><span className="art-line art-line-three"/><span className="public-art-label">{event.type === "workshop" ? "A HANDS-ON WORKSHOP" : "A GATHERING BY GATHER"}</span><span className="public-art-date"><CalendarDays size={14}/>{new Date(event.startsAt).toLocaleDateString("en-US", { month: "long", day: "numeric" })}</span><span className="public-art-title">{event.title}</span></div>
      <div className="public-event-content"><div className="public-event-main-column"><div className="public-eyebrow">{event.category} <span>·</span> {event.type === "workshop" ? "Workshop" : "Event"}</div><h1>{event.title}</h1><p className="public-description">{event.description || "A thoughtful space to learn something, meet someone, or simply spend time well."}</p>
        <div className="public-detail-list"><div><span className="public-detail-icon blue"><CalendarRange size={17}/></span><span><small>When</small><strong>{dateLine}</strong></span></div><div><span className="public-detail-icon mint"><MapPin size={17}/></span><span><small>Where</small><strong>{event.venue || (event.format === "online" ? "Online gathering" : "Location to be announced")}</strong><em>{event.format === "online" ? "Virtual" : event.format === "hybrid" ? "In person + online" : "In person"}</em></span></div>{workshopDetails && <><div><span className="public-detail-icon violet"><Clock3 size={17}/></span><span><small>Time well spent</small><strong>{workshopDetails.durationHours} hour{workshopDetails.durationHours === 1 ? "" : "s"}</strong><em>Led by {workshopDetails.instructor || "your host"}</em></span></div><div><span className="public-detail-icon peach"><Sparkles size={17}/></span><span><small>Materials</small><strong>{workshopDetails.materialCost > 0 ? formatMoney(workshopDetails.materialCost, workshopDetails.currency) : "Included"}</strong><em>{workshopDetails.materialCost > 0 ? "No payment is collected here; contact the organizer for payment details." : "No materials payment is needed."}</em></span></div></>}</div>
        <div className="public-invitation"><span className="invitation-mark">✳</span><p>Come as you are. Leave with something good.</p></div>
      </div>
      <aside className="public-register-card"><span className="register-card-topline"><span className="register-open-indicator"><i/>REGISTRATION {result.registrationOpen ? "OPEN" : "CLOSED"}</span><Users size={17}/></span><h2>Save your<br/>place.</h2><p>We'd love to have you there. It takes just a moment to join.</p><div className="availability-block"><div className="availability-label"><span><Users size={14}/>{result.registrationCount} joined</span><span>{result.remainingSeats} spots left</span></div><div className="availability-track"><i style={{ width: `${Math.min(100, Math.round(result.registrationCount / Math.max(event.capacity, 1) * 100))}%` }}/></div><small>{result.remainingSeats > 0 ? "A little room remains." : "This experience is at capacity."}</small></div>{result.registrationOpen ? <button className="button button-primary register-cta" onClick={() => navigate(`/event/${event.slug}/register`)}>Count me in <ArrowRight size={17}/></button> : <button className="button button-disabled register-cta" disabled>{result.remainingSeats === 0 ? "All places filled" : "Registration closed"}</button>}<span className="register-privacy"><Check size={13}/>Your details are only shared with the event organizer.</span></aside></div>
      <div className="public-footer"><span>gather<span>.</span> · Made for people, by people.</span><span><CalendarDays size={13}/>A moment worth making.</span></div>
    </main>
  </PageMotion>;
}
