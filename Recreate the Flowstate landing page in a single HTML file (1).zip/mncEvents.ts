import type { CompanyEventListing } from "@/components/CompanyEventsSection";

/** Official company-run public events; keep source details current and registration external. */
export const mncEvents: CompanyEventListing[] = [];
