import { useEffect, useState } from "react";
import { CalendarDays, Check, ChevronDown, ImagePlus, LoaderCircle, MapPin, Users, X } from "lucide-react";
import { toast } from "sonner";
import { Modal } from "@/components/Modal";
import { trpc } from "@/lib/trpc";
import { toLocalDateTimeInput } from "@/lib/format";
import type { EventFormInput, WorkspaceEvent } from "@/types";

function initialDate(offsetDays: number, hour: number) {
  const date = new Date();
  date.setDate(date.getDate() + offsetDays);
  date.setHours(hour, 0, 0, 0);
  return toLocalDateTimeInput(date);
}

function blankForm(): EventFormInput {
  return {
    title: "",
    description: "",
    type: "event",
    category: "Community",
    startsAt: initialDate(14, 18),
    endsAt: initialDate(14, 20),
    venue: "",
    format: "in_person",
    capacity: 80,
    coverUrl: "",
    registrationOpensAt: "",
    registrationClosesAt: "",
    registrationFields: [],
    instructor: "",
    durationHours: 2,
    materialCost: 0,
    currency: "USD",
  };
}

export function EventEditorDialog({ open, onClose, event }: { open: boolean; onClose: () => void; event?: WorkspaceEvent | null }) {
  const [form, setForm] = useState<EventFormInput>(blankForm);
  const [customFieldDraft, setCustomFieldDraft] = useState("");
  const utils = trpc.useUtils();
  const create = trpc.events.create.useMutation({
    onSuccess: async () => { toast.success("Your event is ready to shape."); await Promise.all([utils.events.workspaceList.invalidate(), utils.events.overview.invalidate()]); onClose(); },
    onError: (error) => toast.error(error.message),
  });
  const update = trpc.events.update.useMutation({
    onSuccess: async () => { toast.success("Changes saved."); await Promise.all([utils.events.workspaceList.invalidate(), utils.events.overview.invalidate(), utils.events.byId.invalidate()]); onClose(); },
    onError: (error) => toast.error(error.message),
  });
  const busy = create.isPending || update.isPending;
  const isWorkshop = form.type === "workshop";

  useEffect(() => {
    if (!open) return;
    if (!event) { setForm(blankForm()); setCustomFieldDraft(""); return; }
    setForm({
      title: event.title,
      description: event.description,
      type: event.type,
      category: event.category,
      startsAt: toLocalDateTimeInput(event.startsAt),
      endsAt: toLocalDateTimeInput(event.endsAt),
      venue: event.venue,
      format: event.format,
      capacity: event.capacity,
      coverUrl: event.coverUrl || "",
      registrationOpensAt: event.registrationOpensAt ? toLocalDateTimeInput(event.registrationOpensAt) : "",
      registrationClosesAt: event.registrationClosesAt ? toLocalDateTimeInput(event.registrationClosesAt) : "",
      registrationFields: (() => { try { return JSON.parse(event.registrationFields || "[]") as string[]; } catch { return []; } })(),
      instructor: event.workshopDetails?.instructor || "",
      durationHours: event.workshopDetails?.durationHours || 2,
      materialCost: event.workshopDetails?.materialCost || 0,
      currency: event.workshopDetails?.currency || "USD",
    });
  }, [event, open]);

  const set = <K extends keyof EventFormInput>(key: K, value: EventFormInput[K]) => setForm((previous) => ({ ...previous, [key]: value }));
  const addField = () => {
    const value = customFieldDraft.trim();
    const fields = form.registrationFields ?? [];
    if (!value || fields.includes(value)) return;
    set("registrationFields", [...fields, value].slice(0, 8));
    setCustomFieldDraft("");
  };
  const submit = (eventObject: React.FormEvent<HTMLFormElement>) => {
    eventObject.preventDefault();
    if (new Date(form.endsAt) <= new Date(form.startsAt)) { toast.error("The end time must be after the start time."); return; }
    if (form.registrationOpensAt && form.registrationClosesAt && new Date(form.registrationOpensAt) > new Date(form.registrationClosesAt)) { toast.error("Registration must close after it opens."); return; }
    if (event) update.mutate({ ...form, id: event.id });
    else create.mutate(form);
  };

  const registrationFields = form.registrationFields ?? [];
  return <Modal open={open} onClose={onClose} title={event ? "Make a change" : "Create an event"} description={event ? "Keep the details as considered as the experience." : "A few thoughtful details are all it takes to get started."} size="lg">
    <form className="event-form" onSubmit={submit}>
      <div className="form-type-switch" role="group" aria-label="Offering type">
        <button type="button" className={form.type === "event" ? "selected" : ""} onClick={() => set("type", "event")}><CalendarDays size={16} /> Event</button>
        <button type="button" className={form.type === "workshop" ? "selected" : ""} onClick={() => set("type", "workshop")}><Users size={16} /> Workshop</button>
      </div>
      <div className="form-grid">
        <label className="field field-wide"><span>{isWorkshop ? "Workshop name" : "Event name"}<i>*</i></span><input required maxLength={180} value={form.title} onChange={(e) => set("title", e.target.value)} placeholder={isWorkshop ? "e.g. A hands-on flower arranging class" : "e.g. The Makers' Spring Social"} /></label>
        <label className="field"><span>Category</span><select value={form.category} onChange={(e) => set("category", e.target.value)}><option>Community</option><option>Conference</option><option>Networking</option><option>Arts & culture</option><option>Wellness</option><option>Learning</option><option>Product</option><option>Other</option></select><ChevronDown className="field-select-icon" size={15} /></label>
        <label className="field"><span>Capacity<i>*</i></span><div className="input-icon-wrap"><Users size={15} /><input required type="number" min="1" max="50000" value={form.capacity} onChange={(e) => set("capacity", Number(e.target.value))} /></div></label>
        <label className="field"><span>Starts<i>*</i></span><input required type="datetime-local" value={form.startsAt} onChange={(e) => set("startsAt", e.target.value)} /></label>
        <label className="field"><span>Ends<i>*</i></span><input required type="datetime-local" value={form.endsAt} onChange={(e) => set("endsAt", e.target.value)} /></label>
        <label className="field"><span>Format</span><select value={form.format} onChange={(e) => set("format", e.target.value as EventFormInput["format"])}><option value="in_person">In person</option><option value="online">Online</option><option value="hybrid">Hybrid</option></select><ChevronDown className="field-select-icon" size={15} /></label>
        <label className="field"><span>Venue or meeting link</span><div className="input-icon-wrap"><MapPin size={15} /><input maxLength={240} value={form.venue} onChange={(e) => set("venue", e.target.value)} placeholder="Studio name or link" /></div></label>
        <label className="field field-wide"><span>Description</span><textarea rows={3} value={form.description} onChange={(e) => set("description", e.target.value)} placeholder="What will guests experience?" /></label>
        <label className="field field-wide"><span>Cover image URL <small>optional</small></span><div className="input-icon-wrap"><ImagePlus size={15} /><input type="url" value={form.coverUrl || ""} onChange={(e) => set("coverUrl", e.target.value)} placeholder="https://…" /></div></label>
        {isWorkshop && <>
          <label className="field"><span>Instructor</span><input maxLength={160} value={form.instructor} onChange={(e) => set("instructor", e.target.value)} placeholder="Who is leading?" /></label>
          <label className="field"><span>Duration (hours)</span><input type="number" min="0.25" step="0.25" value={form.durationHours} onChange={(e) => set("durationHours", Number(e.target.value))} /></label>
          <label className="field"><span>Materials fee</span><input type="number" min="0" step="0.01" value={form.materialCost} onChange={(e) => set("materialCost", Number(e.target.value))} /></label>
          <label className="field"><span>Currency</span><input maxLength={3} value={form.currency} onChange={(e) => set("currency", e.target.value.toUpperCase())} /></label>
        </>}
      </div>
      <div className="registration-settings">
        <div className="registration-settings-head"><div><strong>Registration details</strong><p>Set the registration window and add questions for guests.</p></div><span className="settings-orbit"><CalendarDays size={17} /></span></div>
        <div className="form-grid registration-dates">
          <label className="field"><span>Opens <small>optional</small></span><input type="datetime-local" value={form.registrationOpensAt || ""} onChange={(e) => set("registrationOpensAt", e.target.value)} /></label>
          <label className="field"><span>Closes <small>optional</small></span><input type="datetime-local" value={form.registrationClosesAt || ""} onChange={(e) => set("registrationClosesAt", e.target.value)} /></label>
        </div>
        <div className="custom-fields-row"><input value={customFieldDraft} onChange={(e) => setCustomFieldDraft(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addField(); } }} placeholder="Add a question, e.g. Dietary requirements" /><button type="button" className="button button-quiet button-small" onClick={addField}>Add question</button></div>
        {registrationFields.length > 0 && <div className="custom-field-tags">{registrationFields.map((field) => <span key={field}>{field}<button type="button" onClick={() => set("registrationFields", registrationFields.filter((item) => item !== field))} aria-label={`Remove ${field}`}><X size={12} /></button></span>)}</div>}
      </div>
      <div className="modal-actions"><button type="button" className="button button-quiet" onClick={onClose}>Cancel</button><button type="submit" className="button button-primary" disabled={busy}>{busy ? <LoaderCircle size={16} className="spin" /> : <Check size={16} />}{event ? "Save changes" : "Save as draft"}</button></div>
    </form>
  </Modal>;
}
