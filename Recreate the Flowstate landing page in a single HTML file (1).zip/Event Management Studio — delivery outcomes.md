# Event Management Studio — delivery outcomes

## 1. Secure MySQL-backed event, workshop, attendee, and registration data — Complete
- Persist event configurations, registration submissions, attendee records, check-in state, and reporting data in the selected MySQL database so the studio remains synchronized and reliable.
- Model users/attendees, events, registrations, workshops, and workshop participation with primary keys, foreign keys, one-to-many and many-to-many relationships, and data-integrity constraints.
- Preserve the reference fields: event title, description, start/end time, location, capacity; workshop title, description, instructor, duration, material cost, maximum participants; registration date, status, payment status; attendee full name, email, phone number, and optional comments.
- Store durable attendee and organizer data in MySQL; do not expose private organizer or attendee records on public pages.

## 2. Distinctive redesign, selectable themes, and event-first organizer dashboard — In progress
- The working website should no longer look AI-created; use a different, considered design and a better dashboard, not the previous Flowstate dark-glass look.
- Replace the near-black glass, ambient glow, and generic gradient-card aesthetic with the chosen Fieldnotes at the Table identity: warm paper surfaces, pine ink, Fraunces display typography, DM Sans interface text, persimmon accents, crisp ledger rules, and restrained motion.
- Provide three switchable app-wide themes in the dashboard palette menu: Fieldnotes (warm paper and persimmon), Orchard (sage and forest green), and Harbor (blue-gray and teal). Choosing a theme updates the interface across routes and persists on the device.
- Use a coherent icon design with clear Lucide line icons, readable icon backgrounds, and accent colors that remain legible in all three themes.
- The dashboard leads with the next published event and a direct route to manage it; when there is no upcoming event, give organizers a clear, useful first-event state.
- Present live registrations, pending follow-ups, published offerings, attendance/check-ins, registration trend, recent guests, and capacity watch in a clear hierarchy, with actions that lead to the related organizer screens.
- Every dashboard button has a working action or destination: event creation opens the editor; theme options apply and persist; event and guest links open the relevant page; the pending-review action filters pending registrations; invitation copy writes the actual public URL and gives success/error feedback; empty-state calls to action open event creation. Do not show decorative inactive controls.
- Responsive navigation and workspace structure still cover dashboard, events, registrations, analytics, and settings across desktop and mobile.
- Keep clear loading, empty, success, error, contrast, focus, and reduced-motion states; dashboard metrics and charts must reflect persisted data rather than invented attendee activity.
- Make “Gather” large and prominent in the desktop organizer taskbar/sidebar and show the same readable brand in the mobile header.
- Give the main organizer interface the supplied ThreeUI 3D animation in a responsive dashboard hero while keeping the actual next published event and live workspace data clearly primary.

## 3. Event and workshop lifecycle plus public event pages — Complete
- Event creation and editing includes title, description, schedule, venue, capacity, status, branding imagery, and registration settings.
- The event directory has card and table views, status tabs, search, sorting, filters, duplication, publishing, and archival actions.
- Public event detail and registration pages present event information and availability, validate attendee details, handle capacity, and show completion states.
- Organizers can create, edit, publish, duplicate, and archive events and workshops; public visitors can browse and register only for published offerings.

## 4. Registration management and attendee profiles — Complete
- Registration management includes attendee profiles, registration status, ticket or confirmation details, notes, edits, cancellations, and bulk actions.
- Public registration collects the attendee's full name and email, supports phone number and optional comments, validates required fields, prevents duplicate registration, and respects event/workshop capacity.
- Registration records retain their registration date, status, and payment status, and are related to their attendee and event/workshop through database keys.
- Attendee and registration searches and filters are contextual to the selected organizer workspace and offering.

## 5. Attendee check-in, analytics, and reporting — Complete
- Attendee check-in is a fast experience with selectable events/workshops, searchable guest lists, manual check-in, duplicate prevention, and live attendance counts.
- Event analytics and reporting cover registrations, attendance, capacity utilization, event performance, and exportable attendee data.
- Global search and contextual filtering work across events and registrations; user-facing views provide clear empty, loading, success, and error states.

## 6. Public/owner routing, authentication, privacy, and delivery configuration — In progress
- `/` provides a searchable/filterable directory of upcoming published public events and workshops. Public visitors can read offerings and register without creating an account.
- All event-management routes live under `/studio` and require both an authenticated session and the approved organizer email; a non-owner account receives a helpful public-browsing path, not organizer access.
- The owner account is synchronized to the existing admin role through the backend OAuth user flow; roles are never trusted from a browser request.
- All page routes are represented in `/manus-routes.json`; Preview health, public event responses, and owner authorization are checked without writing test attendee records.
- The working application runs in the managed project Preview using the initialized React/Express/tRPC/Drizzle stack. Auto-publication remains off.

## 7. Automatic owner-Gmail registration confirmations — In progress
- After a public registration is successfully committed to MySQL, send the attendee a plain-text confirmation from **srinithcm@gmail.com** containing event details and their ticket code.
- Require a securely configured Gmail app password stored only as `GMAIL_APP_PASSWORD` through the Webdev secret-input card; do not ask the owner to post a secret in chat, print/read a stored value, or put it in source code.
- Use the approved built-in `gpt-5-nano` model only for one generic greeting sentence. Do not send attendee names, email addresses, custom answers, comments, ticket codes, or other personal information to the model.
- Generate AI copy only when Gmail is configured; fall back to a static greeting if generation fails. Registration success must not be rolled back by a Gmail/AI failure.
- The visitor success screen truthfully reports whether an email was sent, not configured, or failed; organizers see connection status in Settings. Do not send test email or create real attendee records during development validation.

## 8. Exact ThreeUI GalleryHeading component — Complete
- Integrate `GalleryHeading` from `@designcodeio/threeui` and its official stylesheet into the live website; use the supplied `rising-diagonal` (Matte Rise) variant and exact `mode`, font, weight, size, hue, saturation, and brightness props.
- Use the exact registered source, not an approximation; verify the package's embedded HTML against the supplied canonical SHA-256 `8e42d2d5b4971bfc4d3c485112c3c51909e20a61b8842bc0dcd8db3ffe2d253a`.
- Ensure the canvas renders within the public calendar hero on desktop and mobile without covering or breaking the surrounding visitor navigation and calendar controls.
- Evidence: package HTML decodes to the exact registered SHA-256; TypeScript and production builds pass; desktop (1280×900) and mobile (390×844) renders were inspected; browser hover moved the ring; no browser console errors appeared.

## 9. Official MNC events and workshops — In progress
- Add up to eight verified upcoming events/workshops from Microsoft, Google/Google Cloud, Amazon Web Services, IBM, and Oracle for India or online, with event dates from 2026-11-02 through 2027-01-31.
- For each, show its exact title, official date/time and timezone, online/hybrid/in-person format, known venue or platform, a clear sourced description, official event page, and official registration page. Include fee and capacity only when stated by the company; do not guess missing values.
- Sort the company events by earliest start date and time. Identify them clearly as company-run and externally registered; direct the visitor to the official company registration page instead of collecting attendee details in Gather.
- Do not fabricate or imply an MNC partnership. Prepare the exact public listing payload and obtain the user's final confirmation before publishing the listings.
- Current status: owner studio authentication succeeded. Official event research is running; no MNC listing data has been published or written to the shared event database.

## 10. Chronological event sorting — Complete
- The public event API orders published future events by ascending start time. The owner Events & Workshops directory defaults to “Upcoming” and sorts `startsAt` ascending. The organizer dashboard also sorts published upcoming events earliest first.
- Evidence: source inspection confirmed ascending ordering in the public query, owner directory, and dashboard overview; the requested sort behavior is already present.
