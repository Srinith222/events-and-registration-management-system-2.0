import { Building2, CalendarDays, ExternalLink, Globe2, MapPin, TicketCheck } from "lucide-react";

export type CompanyEventListing = {
  id: string;
  company: string;
  title: string;
  kind: "Event" | "Workshop";
  sortAt: string;
  dateLabel: string;
  location: string;
  format: string;
  description: string;
  fee: string | null;
  officialUrl: string;
  registrationUrl: string;
};

export function CompanyEventsSection({ events }: { events: CompanyEventListing[] }) {
  const ordered = [...events].sort((a, b) => Date.parse(a.sortAt) - Date.parse(b.sortAt));

  return <section className="company-calendar-section" id="company-calendar" aria-labelledby="company-calendar-title">
    <div className="company-calendar-heading">
      <div>
        <p className="print-kicker"><span className="kicker-rule"/>OFFICIAL COMPANY EVENTS & WORKSHOPS</p>
        <h2 id="company-calendar-title">Ideas from the wider world<span className="heading-period">.</span></h2>
        <p className="company-calendar-subtitle">A curated selection from multinational technology companies. Registration stays on each company’s official site.</p>
      </div>
      <span className="company-calendar-count">{String(ordered.length).padStart(2, "0")} {ordered.length === 1 ? "LISTING" : "LISTINGS"}</span>
    </div>

    {ordered.length === 0 ? <div className="company-calendar-empty">No verified company dates are available in this window yet.</div> : <div className="company-event-grid">
      {ordered.map((event, index) => <article className="company-event-card" key={event.id}>
        <div className="company-event-card-top"><span className="company-event-company"><Building2 size={14}/>{event.company}</span><span className="company-event-kind">{event.kind}</span></div>
        <h3>{event.title}</h3>
        <p className="company-event-description">{event.description}</p>
        <div className="company-event-facts">
          <span><CalendarDays size={14}/>{event.dateLabel}</span>
          <span><MapPin size={14}/>{event.location}</span>
          <span><Globe2 size={14}/>{event.format}</span>
          {event.fee && <span><TicketCheck size={14}/>{event.fee}</span>}
        </div>
        <div className="company-event-actions">
          <a href={event.officialUrl} target="_blank" rel="noopener noreferrer">Official details <ExternalLink size={13}/></a>
          <a className="company-event-register" href={event.registrationUrl} target="_blank" rel="noopener noreferrer">Register with {event.company.split(" ")[0]} <ExternalLink size={13}/></a>
        </div>
        <p className="company-event-note">Company-run; registration and capacity are managed externally.</p>
        <span className="company-event-index">{String(index + 1).padStart(2, "0")}</span>
      </article>)}
    </div>}
    <p className="company-calendar-footnote">Dates and availability can change. Check the official event page before making plans.</p>
  </section>;
}
