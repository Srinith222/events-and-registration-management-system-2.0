import { useState } from "react";
import { Link, useLocation, useParams } from "wouter";
import { ArrowLeft, ArrowRight, CalendarClock, Check, Clipboard, ExternalLink, MapPin, Pencil, Share2, TicketCheck, Users } from "lucide-react";
import { toast } from "sonner";
import { EventEditorDialog } from "@/components/EventEditorDialog";
import { ErrorState, LoadingState, PageMotion, StatusBadge } from "@/components/StudioUI";
import { trpc } from "@/lib/trpc";
import { downloadCsv, formatDateRange, formatMoney } from "@/lib/format";
import type { WorkspaceEvent } from "@/types";

export default function EventDetailsPage() {
  const { id: idParam } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const id = Number(idParam);
  const [editorOpen, setEditorOpen] = useState(false);
  const query = trpc.events.byId.useQuery({ id }, { enabled: Number.isInteger(id) && id > 0 });
  const registrationsQuery = trpc.events.registrationList.useQuery(undefined, { staleTime: 20_000 });
  const utils = trpc.useUtils();
  const setStatus = trpc.events.setStatus.useMutation({
    onSuccess: async (_result, variables) => { await Promise.all([query.refetch(), utils.events.workspaceList.invalidate(), utils.events.overview.invalidate()]); toast.success(variables.status === "published" ? "Your event is now live." : variables.status === "archived" ? "Event archived." : "Back to draft."); },
    onError: (error) => toast.error(error.message),
  });
  const event = query.data;
  const guestList = (registrationsQuery.data ?? []).filter((item) => item.eventId === id);
  const copyPublicLink = async () => {
    if (!event) return;
    await navigator.clipboard.writeText(`${window.location.origin}/event/${event.slug}`);
    toast.success("Public event link copied.");
  };
  const exportGuests = () => {
    downloadCsv(`${event?.slug || "event"}-attendees.csv`, guestList.map((item) => ({ name: item.fullName, email: item.email, phone: item.phone, status: item.status, payment: item.paymentStatus, ticket: item.ticketCode, checkedIn: item.checkedInAt ? "Yes" : "No", registeredAt: item.registeredAt.toISOString() })));
    toast.success("Attendee list downloaded.");
  };

  if (query.isLoading) return <PageMotion><LoadingState label="Opening event details…" /></PageMotion>;
  if (query.error || !event) return <ErrorState message={query.error?.message || "This event could not be found."} onRetry={() => query.refetch()}/>;

  const tone = ["blue", "violet", "mint", "peach"][event.id % 4];
  return <PageMotion className="event-details-page">
    <Link href="/events" className="back-link"><ArrowLeft size={15}/>Back to events</Link>
    <div className="detail-cover-row"><div className={`detail-cover tone-${tone}${event.coverUrl ? " has-cover" : ""}`}>{event.coverUrl && <img className="cover-image" src={event.coverUrl} loading="lazy" alt=""/>}<span className="art-sun"/><span className="art-line art-line-one"/><span className="art-line art-line-two"/><span className="art-line art-line-three"/><span className="detail-cover-badge">{event.type === "workshop" ? "WORKSHOP" : event.category.toUpperCase()}</span><span className="detail-cover-icon"><CalendarClock size={27}/></span></div>
      <div className="detail-cover-info"><div className="detail-topline"><span className="event-category">{event.type === "workshop" ? "Workshop" : event.category}</span><StatusBadge status={event.status}/></div><h1>{event.title}</h1><p>{event.description || "An experience made for bringing people together."}</p><div className="detail-meta"><span><CalendarClock size={15}/>{formatDateRange(event.startsAt, event.endsAt)}</span><span><MapPin size={15}/>{event.venue || (event.format === "online" ? "Online event" : "Venue to be announced")}</span><span><Users size={15}/>{event.registrationCount} of {event.capacity} places</span></div>
        <div className="detail-actions"><button className="button button-primary" onClick={() => setEditorOpen(true)}><Pencil size={15}/>Edit details</button>{event.status === "published" ? <><button className="button button-secondary" onClick={copyPublicLink}><Share2 size={15}/>Copy public link</button><Link className="button button-quiet" href={`/event/${event.slug}`}><ExternalLink size={15}/>View public page</Link></> : <button className="button button-secondary" onClick={() => setStatus.mutate({ id: event.id, status: "published" })}><ExternalLink size={15}/>Publish event</button>}</div>
      </div>
    </div>
    <div className="detail-stat-grid"><div className="detail-stat"><span className="detail-stat-icon blue"><Users size={17}/></span><div><small>Registrations</small><strong>{event.registrationCount}<i> / {event.capacity}</i></strong></div></div><div className="detail-stat"><span className="detail-stat-icon mint"><TicketCheck size={17}/></span><div><small>Checked in</small><strong>{event.checkInCount}<i> guests</i></strong></div></div><div className="detail-stat"><span className="detail-stat-icon violet"><CalendarClock size={17}/></span><div><small>Format</small><strong>{event.format === "in_person" ? "In person" : event.format === "online" ? "Online" : "Hybrid"}</strong></div></div><div className="detail-stat"><span className="detail-stat-icon peach"><Share2 size={17}/></span><div><small>Registration close</small><strong>{event.registrationClosesAt ? new Date(event.registrationClosesAt).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "Open until full"}</strong></div></div></div>
    {event.type === "workshop" && event.workshopDetails && <div className="workshop-detail-strip"><span><strong>Instructor</strong>{event.workshopDetails.instructor || "To be announced"}</span><span><strong>Duration</strong>{event.workshopDetails.durationHours} hours</span><span><strong>Materials</strong>{event.workshopDetails.materialCost > 0 ? formatMoney(event.workshopDetails.materialCost, event.workshopDetails.currency) : "Included"}</span><span><strong>Maximum participants</strong>{event.workshopDetails.maxParticipants}</span></div>}
    <section className="panel detail-guests-panel"><div className="detail-guests-head"><div><h2>Attendee list</h2><p>People who saved a place for this experience.</p></div><div className="detail-guest-actions"><button className="button button-quiet button-small" onClick={exportGuests} disabled={!guestList.length}><Clipboard size={14}/>Export list</button><Link className="text-link" href={`/registrations?event=${event.id}`}>Manage all <ArrowRight size={14}/></Link></div></div>
      {registrationsQuery.isLoading ? <LoadingState label="Checking the guest list…"/> : guestList.length ? <div className="recent-list detail-guest-list">{guestList.slice(0, 7).map((guest, index) => <div className="recent-item" key={`${guest.itemType}-${guest.id}`}><span className={`guest-avatar guest-tone-${index % 5}`}>{guest.fullName.split(/\s+/).slice(0,2).map((part) => part[0]).join("").toUpperCase()}</span><span className="recent-guest"><strong>{guest.fullName}</strong><small>{guest.email}</small></span><span className="ticket-tag">{guest.ticketCode}</span><StatusBadge status={guest.status}/></div>)}</div> : <div className="detail-guest-empty"><span><Users size={21}/></span><div><strong>The first seat is still open.</strong><p>Publish this experience and share its registration page with your people.</p></div>{event.status !== "published" && <button className="button button-small button-primary" onClick={() => setStatus.mutate({ id: event.id, status: "published" })}>Publish event</button>}</div>}
    </section>
    <EventEditorDialog open={editorOpen} onClose={() => setEditorOpen(false)} event={event as WorkspaceEvent}/>
  </PageMotion>;
}
