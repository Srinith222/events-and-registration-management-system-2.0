import { relations } from "drizzle-orm";
import {
  attendees,
  events,
  registrations,
  users,
  workshopParticipants,
  workshops,
} from "./schema";

export const usersRelations = relations(users, ({ many }) => ({
  events: many(events),
  attendees: many(attendees),
}));

export const eventsRelations = relations(events, ({ one, many }) => ({
  owner: one(users, { fields: [events.ownerId], references: [users.id] }),
  workshop: one(workshops),
  registrations: many(registrations),
}));

export const workshopsRelations = relations(workshops, ({ one, many }) => ({
  event: one(events, { fields: [workshops.eventId], references: [events.id] }),
  participants: many(workshopParticipants),
}));

export const attendeesRelations = relations(attendees, ({ one, many }) => ({
  owner: one(users, { fields: [attendees.ownerId], references: [users.id] }),
  registrations: many(registrations),
  workshopParticipations: many(workshopParticipants),
}));

export const registrationsRelations = relations(registrations, ({ one }) => ({
  event: one(events, { fields: [registrations.eventId], references: [events.id] }),
  attendee: one(attendees, { fields: [registrations.attendeeId], references: [attendees.id] }),
}));

export const workshopParticipantsRelations = relations(workshopParticipants, ({ one }) => ({
  workshop: one(workshops, { fields: [workshopParticipants.workshopId], references: [workshops.id] }),
  attendee: one(attendees, { fields: [workshopParticipants.attendeeId], references: [attendees.id] }),
}));
